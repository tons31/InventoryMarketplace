<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/koneksi.php';

function fetch_all($sql)
{
    global $koneksi;
    $result = mysqli_query($koneksi, $sql);
    $rows = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
    }
    return $rows;
}

function fetch_one($sql)
{
    global $koneksi;
    $result = mysqli_query($koneksi, $sql);
    return $result ? mysqli_fetch_assoc($result) : null;
}

function num_rows($sql)
{
    global $koneksi;
    $result = mysqli_query($koneksi, $sql);
    return $result ? mysqli_num_rows($result) : 0;
}

function log_activity($role, $user_id, $nama_user, $aktivitas)
{
    global $koneksi;
    $role = mysqli_real_escape_string($koneksi, $role);
    $user_id = (int) $user_id;
    $nama_user = mysqli_real_escape_string($koneksi, $nama_user);
    $aktivitas = mysqli_real_escape_string($koneksi, $aktivitas);
    mysqli_query($koneksi, "INSERT INTO tb_log_aktivitas(role_user,id_user,nama_user,aktivitas,waktu) VALUES('$role',$user_id,'$nama_user','$aktivitas',NOW())");
}

function require_post_fields($fields)
{
    foreach ($fields as $field) {
        if (!isset($_POST[$field]) || trim((string) $_POST[$field]) === '') {
            return false;
        }
    }
    return true;
}

function stok_item($id_item)
{
    $id_item = (int) $id_item;
    $row = fetch_one("SELECT stok FROM tb_item WHERE id_item = $id_item");
    return $row ? (int) $row['stok'] : 0;
}

function update_stok_item($id_item, $stok_baru)
{
    global $koneksi;
    $id_item = (int) $id_item;
    $stok_baru = (int) $stok_baru;
    mysqli_query($koneksi, "UPDATE tb_item SET stok = $stok_baru, updated_at = NOW() WHERE id_item = $id_item");
}

function badge_status($status)
{
    $status = strtolower((string) $status);
    $map = [
        'menunggu' => 'label-warning',
        'disetujui' => 'label-success',
        'ditolak' => 'label-danger',
        'selesai' => 'label-primary',
        'aktif' => 'label-success',
        'nonaktif' => 'label-default'
    ];
    $class = isset($map[$status]) ? $map[$status] : 'label-default';
    return '<span class="label ' . $class . '">' . esc(ucfirst($status)) . '</span>';
}

function session_timeout_check()
{
    global $session_timeout;
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $session_timeout) {
        session_unset();
        session_destroy();
        session_start();
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Sesi berakhir karena tidak ada aktivitas.'];
    }
    $_SESSION['last_activity'] = time();
}

function current_month_range()
{
    return [date('Y-m-01'), date('Y-m-t')];
}

function safe_ratio($num, $den)
{
    if ((float) $den <= 0) {
        return 0;
    }
    return round(((float) $num / (float) $den) * 100, 1);
}

function monthly_inventory_series($months = 6, $role = null, $userId = null)
{
    $months = max(1, (int) $months);
    $labels = [];
    $monthKeys = [];
    for ($i = $months - 1; $i >= 0; $i--) {
        $monthKeys[] = date('Y-m', strtotime("-{$i} month"));
        $labels[] = date('M Y', strtotime("-{$i} month"));
    }

    $whereMasuk = "WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL " . ($months - 1) . " MONTH)";
    $whereKeluar = "WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL " . ($months - 1) . " MONTH)";
    if ($role && $userId) {
        $role = addslashes($role);
        $userId = (int) $userId;
        $whereMasuk .= " AND input_role = '$role' AND input_by = $userId";
        $whereKeluar .= " AND input_role = '$role' AND input_by = $userId";
    }

    $masukRows = fetch_all("SELECT DATE_FORMAT(tanggal,'%Y-%m') bulan, SUM(qty) total FROM tb_item_masuk $whereMasuk GROUP BY DATE_FORMAT(tanggal,'%Y-%m')");
    $keluarRows = fetch_all("SELECT DATE_FORMAT(tanggal,'%Y-%m') bulan, SUM(qty) total FROM tb_item_keluar $whereKeluar GROUP BY DATE_FORMAT(tanggal,'%Y-%m')");

    $masukMap = [];
    foreach ($masukRows as $row) {
        $masukMap[$row['bulan']] = (int) $row['total'];
    }
    $keluarMap = [];
    foreach ($keluarRows as $row) {
        $keluarMap[$row['bulan']] = (int) $row['total'];
    }

    $masuk = [];
    $keluar = [];
    foreach ($monthKeys as $key) {
        $masuk[] = isset($masukMap[$key]) ? (int) $masukMap[$key] : 0;
        $keluar[] = isset($keluarMap[$key]) ? (int) $keluarMap[$key] : 0;
    }

    return ['labels' => $labels, 'masuk' => $masuk, 'keluar' => $keluar];
}


function svg_wrap_lines($text, $maxChars = 28)
{
    $text = trim((string) $text);
    if ($text === '') return ['-'];
    $words = preg_split('/\s+/', $text);
    $lines = [];
    $current = '';
    foreach ($words as $word) {
        $candidate = $current === '' ? $word : $current . ' ' . $word;
        if (function_exists('mb_strlen') ? mb_strlen($candidate) <= $maxChars : strlen($candidate) <= $maxChars) {
            $current = $candidate;
        } else {
            if ($current !== '') $lines[] = $current;
            $current = $word;
        }
    }
    if ($current !== '') $lines[] = $current;
    return array_slice($lines, 0, 2);
}

function svg_line_chart($labels, $seriesA, $seriesB, $seriesALabel = 'Masuk', $seriesBLabel = 'Keluar')
{
    $width = 760;
    $height = 320;
    $paddingLeft = 54;
    $paddingRight = 24;
    $paddingTop = 28;
    $paddingBottom = 52;
    $plotWidth = $width - $paddingLeft - $paddingRight;
    $plotHeight = $height - $paddingTop - $paddingBottom;
    $count = max(1, count($labels));
    $maxValue = max(array_merge([1], array_map('intval', $seriesA), array_map('intval', $seriesB)));
    $stepX = $count > 1 ? $plotWidth / ($count - 1) : 0;

    $toPoints = function ($series) use ($count, $paddingLeft, $paddingTop, $plotHeight, $maxValue, $stepX) {
        $points = [];
        for ($i = 0; $i < $count; $i++) {
            $value = isset($series[$i]) ? (int) $series[$i] : 0;
            $x = $paddingLeft + ($stepX * $i);
            $y = $paddingTop + $plotHeight - (($value / $maxValue) * $plotHeight);
            $points[] = round($x, 2) . ',' . round($y, 2);
        }
        return implode(' ', $points);
    };

    $pointsA = $toPoints($seriesA);
    $pointsB = $toPoints($seriesB);
    $grid = '';
    for ($i = 0; $i <= 4; $i++) {
        $y = $paddingTop + ($plotHeight / 4) * $i;
        $value = round($maxValue - (($maxValue / 4) * $i));
        $grid .= '<line x1="' . $paddingLeft . '" y1="' . $y . '" x2="' . ($width - $paddingRight) . '" y2="' . $y . '" stroke="rgba(148,163,184,.35)" stroke-dasharray="4 4" />';
        $grid .= '<text x="10" y="' . ($y + 6) . '" font-size="14" font-weight="700" fill="#64748b">' . $value . '</text>';
    }
    $xLabels = '';
    for ($i = 0; $i < $count; $i++) {
        $x = $paddingLeft + ($stepX * $i);
        $xLabels .= '<text x="' . $x . '" y="' . ($height - 14) . '" text-anchor="middle" font-size="14" font-weight="700" fill="#64748b">' . htmlspecialchars($labels[$i]) . '</text>';
    }

    return '<svg viewBox="0 0 ' . $width . ' ' . $height . '" class="svg-chart" role="img" aria-label="Grafik pergerakan item">'
        . '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" rx="18" fill="#fff" />'
        . $grid
        . '<polyline fill="none" stroke="#2563eb" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" points="' . $pointsA . '" />'
        . '<polyline fill="none" stroke="#0ea5e9" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" points="' . $pointsB . '" />'
        . $xLabels
        . '<circle cx="' . $paddingLeft . '" cy="18" r="6" fill="#2563eb" /><text x="66" y="24" font-size="16" font-weight="700" fill="#0f172a">' . htmlspecialchars($seriesALabel) . '</text>'
        . '<circle cx="240" cy="18" r="6" fill="#0ea5e9" /><text x="252" y="24" font-size="16" font-weight="700" fill="#0f172a">' . htmlspecialchars($seriesBLabel) . '</text>'
        . '</svg>';
}

function svg_bar_chart($rows, $labelKey, $valueKey, $color = '#2563eb')
{
    $width = 1000;
    $height = 306;
    $paddingLeft = 345;
    $paddingRight = 56;
    $paddingTop = 18;
    $barGap = 28;
    $barHeight = 22;
    $count = max(1, count($rows));
    $svgHeight = max($height, $paddingTop + ($count * ($barHeight + $barGap)) + 18);
    $maxValue = 1;
    foreach ($rows as $row) {
        $maxValue = max($maxValue, (int) $row[$valueKey]);
    }
    $trackWidth = $width - $paddingLeft - $paddingRight;
    $out = '<svg viewBox="0 0 ' . $width . ' ' . $svgHeight . '" class="svg-chart" role="img" aria-label="Grafik batang" preserveAspectRatio="xMinYMin meet">';
    foreach ($rows as $i => $row) {
        $y = $paddingTop + ($i * ($barHeight + $barGap));
        $label = trim((string) $row[$labelKey]);
        $value = (int) $row[$valueKey];
        $barWidth = ($trackWidth * $value) / $maxValue;

        $lines = svg_wrap_lines($label, 30);
        $lineHeight = 18;
        $blockHeight = max(1, count($lines)) * $lineHeight;
        $textStartY = $y + (($barHeight - $blockHeight) / 2) + 10;

        foreach ($lines as $lineIndex => $line) {
            $textY = $textStartY + ($lineIndex * $lineHeight);
            $out .= '<text x="18" y="' . round($textY, 2) . '" font-size="18" font-weight="700" fill="#243244">' . htmlspecialchars($line) . '</text>';
        }

        $out .= '<rect x="' . $paddingLeft . '" y="' . $y . '" width="' . $trackWidth . '" height="' . $barHeight . '" rx="10" fill="#dbe6f2" />';
        $out .= '<rect x="' . $paddingLeft . '" y="' . $y . '" width="' . round($barWidth, 2) . '" height="' . $barHeight . '" rx="10" fill="' . $color . '" />';

        $valueX = min($width - 18, $paddingLeft + $barWidth + 10);
        $out .= '<text x="' . round($valueX, 2) . '" y="' . ($y + 16) . '" font-size="15" font-weight="800" fill="#475569">' . $value . '</text>';
    }
    $out .= '</svg>';
    return $out;
}

function ensure_dir($path)
{
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
    }
}

function handle_photo_upload($inputName, $folder, $oldPath = '')
{
    if (empty($_FILES[$inputName]) || !isset($_FILES[$inputName]['tmp_name']) || $_FILES[$inputName]['error'] === UPLOAD_ERR_NO_FILE) {
        return $oldPath;
    }
    if ($_FILES[$inputName]['error'] !== UPLOAD_ERR_OK) {
        return $oldPath;
    }

    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($_FILES[$inputName]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        return $oldPath;
    }

    $baseDir = __DIR__ . '/uploads/' . trim($folder, '/');
    ensure_dir($baseDir);
    $fileName = uniqid('foto_', true) . '.' . $ext;
    $targetPath = $baseDir . '/' . $fileName;
    if (!move_uploaded_file($_FILES[$inputName]['tmp_name'], $targetPath)) {
        return $oldPath;
    }

    if ($oldPath) {
        delete_uploaded_file($oldPath);
    }
    return 'uploads/' . trim($folder, '/') . '/' . $fileName;
}

function delete_uploaded_file($relativePath)
{
    $relativePath = trim((string) $relativePath);
    if ($relativePath === '') {
        return;
    }
    $full = __DIR__ . '/' . ltrim($relativePath, '/');
    if (is_file($full)) {
        @unlink($full);
    }
}

function initials($name)
{
    $name = trim((string) $name);
    if ($name === '') {
        return 'NA';
    }
    $parts = preg_split('/\s+/', $name);
    $out = '';
    foreach ($parts as $part) {
        $out .= strtoupper(substr($part, 0, 1));
        if (strlen($out) >= 2) {
            break;
        }
    }
    return $out ?: 'NA';
}

function photo_tag($path, $name, $class = 'avatar-thumb')
{
    $full = __DIR__ . '/' . ltrim((string) $path, '/');
    if ($path && is_file($full)) {
        return '<img src="../' . esc($path) . '" alt="' . esc($name) . '" class="' . esc($class) . '">';
    }
    return '<div class="avatar-placeholder ' . esc($class) . '">' . esc(initials($name)) . '</div>';
}

function photo_tag_root($path, $name, $class = 'avatar-thumb')
{
    $full = __DIR__ . '/' . ltrim((string) $path, '/');
    if ($path && is_file($full)) {
        return '<img src="' . esc($path) . '" alt="' . esc($name) . '" class="' . esc($class) . '">';
    }
    return '<div class="avatar-placeholder ' . esc($class) . '">' . esc(initials($name)) . '</div>';
}

function selected_attr($a, $b)
{
    return (string) $a === (string) $b ? 'selected' : '';
}
