CREATE DATABASE IF NOT EXISTS inventory_ksi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventory_ksi;

DROP TABLE IF EXISTS tb_log_aktivitas;
DROP TABLE IF EXISTS tb_ajuan;
DROP TABLE IF EXISTS tb_item_keluar;
DROP TABLE IF EXISTS tb_item_masuk;
DROP TABLE IF EXISTS tb_item;
DROP TABLE IF EXISTS tb_rak;
DROP TABLE IF EXISTS tb_marketplace;
DROP TABLE IF EXISTS tb_petugas;
DROP TABLE IF EXISTS tb_admin;

CREATE TABLE tb_admin (
  id_admin INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  foto VARCHAR(255) NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'aktif',
  created_at DATETIME NULL
);

CREATE TABLE tb_petugas (
  id_petugas INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  foto VARCHAR(255) NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'aktif',
  created_at DATETIME NULL
);

CREATE TABLE tb_marketplace (
  id_marketplace INT AUTO_INCREMENT PRIMARY KEY,
  nama_marketplace VARCHAR(100) NOT NULL,
  nama_toko VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'aktif',
  created_at DATETIME NULL
);

CREATE TABLE tb_rak (
  id_rak INT AUTO_INCREMENT PRIMARY KEY,
  kode_rak VARCHAR(30) NOT NULL,
  nama_rak VARCHAR(100) NOT NULL,
  created_at DATETIME NULL
);

CREATE TABLE tb_item (
  id_item INT AUTO_INCREMENT PRIMARY KEY,
  kode_item VARCHAR(30) NOT NULL,
  nama_item VARCHAR(150) NOT NULL,
  id_rak INT NULL,
  stok INT NOT NULL DEFAULT 0,
  stok_minimum INT NOT NULL DEFAULT 5,
  status VARCHAR(20) NOT NULL DEFAULT 'aktif',
  created_at DATETIME NULL,
  updated_at DATETIME NULL,
  CONSTRAINT fk_item_rak FOREIGN KEY (id_rak) REFERENCES tb_rak(id_rak) ON DELETE SET NULL
);

CREATE TABLE tb_item_masuk (
  id_masuk INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL,
  id_item INT NOT NULL,
  qty INT NOT NULL,
  sumber VARCHAR(100) NULL,
  catatan VARCHAR(255) NULL,
  input_by INT NULL,
  input_role VARCHAR(20) NULL,
  created_at DATETIME NULL,
  CONSTRAINT fk_masuk_item FOREIGN KEY (id_item) REFERENCES tb_item(id_item) ON DELETE CASCADE
);

CREATE TABLE tb_item_keluar (
  id_keluar INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL,
  id_item INT NOT NULL,
  qty INT NOT NULL,
  id_marketplace INT NOT NULL,
  tujuan VARCHAR(100) NULL,
  catatan VARCHAR(255) NULL,
  input_by INT NULL,
  input_role VARCHAR(20) NULL,
  created_at DATETIME NULL,
  CONSTRAINT fk_keluar_item FOREIGN KEY (id_item) REFERENCES tb_item(id_item) ON DELETE CASCADE,
  CONSTRAINT fk_keluar_marketplace FOREIGN KEY (id_marketplace) REFERENCES tb_marketplace(id_marketplace) ON DELETE CASCADE
);

CREATE TABLE tb_ajuan (
  id_ajuan INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL,
  id_petugas INT NOT NULL,
  nama_petugas VARCHAR(100) NOT NULL,
  id_item INT NOT NULL,
  qty INT NOT NULL,
  keperluan VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'menunggu',
  reviewed_by VARCHAR(100) NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NULL,
  CONSTRAINT fk_ajuan_petugas FOREIGN KEY (id_petugas) REFERENCES tb_petugas(id_petugas) ON DELETE CASCADE,
  CONSTRAINT fk_ajuan_item FOREIGN KEY (id_item) REFERENCES tb_item(id_item) ON DELETE CASCADE
);

CREATE TABLE tb_log_aktivitas (
  id_log INT AUTO_INCREMENT PRIMARY KEY,
  role_user VARCHAR(20) NOT NULL,
  id_user INT NOT NULL,
  nama_user VARCHAR(100) NOT NULL,
  aktivitas VARCHAR(255) NOT NULL,
  waktu DATETIME NOT NULL
);

INSERT INTO tb_admin (nama, foto, username, password, status, created_at) VALUES
('Administrator KSI', NULL, 'admin', '$2y$12$rCci0SVODlqYiVdTiZtAiOo/p3zg.qwpJxCsnYf1LCINSstSJdkCu', 'aktif', NOW());

INSERT INTO tb_petugas (nama, foto, username, password, status, created_at) VALUES
('Petugas Gudang', NULL, 'petugas', '$2y$12$ykuFWrD7Z.E5xcE4yOPi3erDTlkxLRfTZlSdri8HoSaUneYNsBSNq', 'aktif', NOW());

INSERT INTO tb_marketplace (nama_marketplace, nama_toko, status, created_at) VALUES
('Shopee', 'KSI Home Official', 'aktif', NOW()),
('Tokopedia', 'KSI Official Store', 'aktif', NOW()),
('TikTok Shop', 'KSI Home Live', 'aktif', NOW());

INSERT INTO tb_rak (kode_rak, nama_rak, created_at) VALUES
('A-01', 'Rak Gudang A1', NOW()),
('B-02', 'Rak Gudang B2', NOW()),
('C-03', 'Rak Gudang C3', NOW());

INSERT INTO tb_item (kode_item, nama_item, id_rak, stok, stok_minimum, status, created_at, updated_at) VALUES
('BRG-001', 'Rice Cooker 1.8L', 1, 25, 5, 'aktif', NOW(), NOW()),
('BRG-002', 'Electric Kettle 2L', 2, 12, 4, 'aktif', NOW(), NOW()),
('BRG-003', 'Setrika Uap Premium', 3, 8, 3, 'aktif', NOW(), NOW());

INSERT INTO tb_item_masuk (tanggal, id_item, qty, sumber, catatan, input_by, input_role, created_at) VALUES
(DATE_SUB(CURDATE(), INTERVAL 5 MONTH), 1, 14, 'Gudang Pusat', 'Restock bulanan awal', 1, 'admin', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 4 MONTH), 2, 11, 'Gudang Pusat', 'Restock bulanan', 1, 'admin', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 3 MONTH), 3, 9, 'Supplier Lokal', 'Restock bulanan', 1, 'admin', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 2 MONTH), 1, 12, 'Gudang Pusat', 'Restock promo', 1, 'admin', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), 2, 10, 'Supplier Lokal', 'Restock gudang', 1, 'admin', NOW()),
(CURDATE(), 1, 10, 'Gudang Pusat', 'Restock awal', 1, 'admin', NOW()),
(CURDATE(), 2, 5, 'Supplier Lokal', 'Restock rutin', 1, 'admin', NOW());

INSERT INTO tb_item_keluar (tanggal, id_item, qty, id_marketplace, tujuan, catatan, input_by, input_role, created_at) VALUES
(DATE_SUB(CURDATE(), INTERVAL 5 MONTH), 1, 6, 1, 'Shopee', 'Pesanan flash sale', 1, 'petugas', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 4 MONTH), 2, 5, 2, 'Tokopedia', 'Pesanan kampanye', 1, 'petugas', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 3 MONTH), 3, 4, 3, 'TikTok Shop', 'Pesanan rutin', 1, 'petugas', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 2 MONTH), 1, 8, 1, 'Shopee', 'Pesanan promo besar', 1, 'petugas', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), 2, 7, 2, 'Tokopedia', 'Pesanan bulanan', 1, 'petugas', NOW()),
(CURDATE(), 1, 2, 1, 'Shopee', 'Pesanan harian', 1, 'petugas', NOW()),
(CURDATE(), 1, 2, 2, 'Tokopedia', 'Update stok harian', 1, 'petugas', NOW()),
(CURDATE(), 1, 2, 3, 'TikTok Shop', 'Update stok harian', 1, 'petugas', NOW()),
(CURDATE(), 3, 1, 3, 'TikTok Shop', 'Pesanan harian', 1, 'petugas', NOW());

INSERT INTO tb_ajuan (tanggal, id_petugas, nama_petugas, id_item, qty, keperluan, status, created_at) VALUES
(DATE_SUB(CURDATE(), INTERVAL 3 DAY), 1, 'Petugas Gudang', 2, 3, 'Upload stok promo marketplace', 'menunggu', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 10 DAY), 1, 'Petugas Gudang', 1, 2, 'Permintaan stok untuk event live', 'disetujui', NOW()),
(DATE_SUB(CURDATE(), INTERVAL 18 DAY), 1, 'Petugas Gudang', 3, 1, 'Cadangan stok order prioritas', 'ditolak', NOW());

INSERT INTO tb_log_aktivitas (role_user, id_user, nama_user, aktivitas, waktu) VALUES
('admin', 1, 'Administrator KSI', 'Setup awal sistem inventory', NOW()),
('petugas', 1, 'Petugas Gudang', 'Mencatat distribusi stok marketplace', NOW());
