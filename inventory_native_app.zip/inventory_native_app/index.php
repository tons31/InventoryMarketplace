<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc($site_title); ?></title>
    <link rel="stylesheet" href="vendor/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/modern.css">
    <style>
        .hero-kpi {margin-top:25px}
        .hero-kpi .card{background:linear-gradient(145deg,rgba(255,255,255,.97),rgba(219,234,254,.88));border:1px solid rgba(56,189,248,.28);border-radius:22px;padding:24px;box-shadow:0 24px 60px rgba(37,99,235,.18),0 0 0 1px rgba(255,255,255,.55) inset;margin-bottom:15px;backdrop-filter:blur(14px)}
        .hero-cta .btn{margin-right:10px;margin-bottom:10px}
        .landing-shell{background:radial-gradient(circle at 12% 18%,rgba(0,174,255,.32),transparent 30%),radial-gradient(circle at 88% 8%,rgba(37,99,235,.30),transparent 28%),linear-gradient(135deg,#e0f2fe 0%,#eff6ff 42%,#dbeafe 100%);min-height:100vh;overflow-x:hidden}
        .hero-panel{padding:82px 0 50px;position:relative}
        .hero-title{font-size:46px;font-weight:800;line-height:1.13;color:#061a3a;letter-spacing:-.035em;text-shadow:0 12px 35px rgba(37,99,235,.16)}
        .hero-text{font-size:18px;color:#315173;max-width:700px;margin:20px 0 28px;line-height:1.75}
        .mini-pill{display:inline-block;background:linear-gradient(135deg,#0284c7,#2563eb 55%,#1d4ed8);color:#fff;padding:10px 18px;border-radius:999px;font-weight:800;margin-bottom:22px;box-shadow:0 14px 34px rgba(37,99,235,.30);letter-spacing:.02em}
        .feature-box{background:linear-gradient(180deg,rgba(255,255,255,.98),rgba(239,246,255,.92));border:1px solid rgba(59,130,246,.18);border-radius:22px;padding:26px;box-shadow:0 18px 45px rgba(37,99,235,.12);height:100%;transition:.22s ease}
        .section-space{padding:20px 0 60px}

        .landing-shell:before{content:"";position:fixed;inset:auto -120px -180px auto;width:420px;height:420px;border-radius:50%;background:rgba(14,165,233,.24);filter:blur(12px);pointer-events:none}
        .landing-shell .navbar-brand,.landing-shell .navbar-nav>li>a{color:#fff!important;font-weight:700}
        .landing-shell .navbar-nav>li>a:hover{background:rgba(255,255,255,.14)!important;color:#e0f2fe!important}
        .landing-shell .btn-primary{background:linear-gradient(135deg,#00a6ff,#2563eb 58%,#1d4ed8);border:0;box-shadow:0 18px 38px rgba(37,99,235,.35)}
        .landing-shell .btn-default{background:rgba(255,255,255,.92);border:1px solid rgba(37,99,235,.18);color:#0759c9;box-shadow:0 14px 30px rgba(37,99,235,.14);font-weight:800}
        .landing-shell .btn-default:hover{background:#e0f2fe;color:#024fb3}
        .feature-box:hover{transform:translateY(-5px);box-shadow:0 26px 58px rgba(37,99,235,.18);border-color:rgba(14,165,233,.38)}
        .feature-box h4{color:#0b3b7e;font-weight:800}
        .feature-box .fa.text-primary{color:#0284ff}
        .hero-kpi h4{color:#0b3b7e;font-weight:800}
        .hero-kpi .fa.text-success{color:#0284ff}
    </style>
</head>
<body class="landing-shell">
<nav class="navbar navbar-default" style="background:linear-gradient(90deg,#015dbe,#0284c7 45%,#2563eb);border:none;box-shadow:0 14px 36px rgba(37,99,235,.28)">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php"><strong>Pengelola Inventory Marketplace KSI</strong></a>
        </div>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="#fitur">Fitur</a></li>
            <li><a href="#alur">Alur</a></li>
            <li><a href="admin/login.php">Admin</a></li>
            <li><a href="petugas/login.php">Petugas</a></li>
        </ul>
    </div>
</nav>
<section class="hero-panel">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <span class="mini-pill">PT. KSI HOME APPLIANCES</span>
                <div class="hero-title">Kelola stok lebih cepat</div>
                <div class="hero-text">Pantau stok, item masuk, item keluar, dan ajuan dari satu tempat. Tampilannya ringkas agar kerja gudang lebih cepat.</div>
                <div class="hero-cta">
                    <a href="admin/login.php" class="btn btn-primary btn-lg"><i class="fa fa-user-secret"></i> Masuk Admin</a>
                    <a href="petugas/login.php" class="btn btn-default btn-lg"><i class="fa fa-users"></i> Masuk Petugas</a>
                </div>
            </div>
            <div class="col-md-5 hero-kpi">
                <div class="card">
                    <h4>Fitur Untuk Pengelola Stok Marketplace Pada Inventori Anda</h4>
                    <ul class="list-unstyled" style="line-height:2">
                        <li><i class="fa fa-check text-success"></i> Stok lebih mudah dipantau</li>
                        <li><i class="fa fa-check text-success"></i> Item masuk dan keluar tercatat</li>
                        <li><i class="fa fa-check text-success"></i> Ajuan lebih jelas</li>
                        <li><i class="fa fa-check text-success"></i> Dashboard cepat dibaca</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="fitur" class="section-space">
    <div class="container">
        <div class="row">
            <div class="col-md-4"><div class="feature-box"><h4><i class="fa fa-cubes text-primary"></i> Stok Item</h4><p>Data item, rak, stok minimum, dan riwayat mutasi tersimpan rapi.</p></div></div>
            <div class="col-md-4"><div class="feature-box"><h4><i class="fa fa-exchange text-primary"></i> Aktivitas Gudang</h4><p>Catat item masuk, item keluar, dan ajuan sesuai peran pengguna.</p></div></div>
            <div class="col-md-4"><div class="feature-box"><h4><i class="fa fa-line-chart text-primary"></i> Dashboard</h4><p>Lihat ringkasan stok, ajuan, dan pergerakan item dengan cepat.</p></div></div>
        </div>
    </div>
</section>
<section id="alur" class="section-space" style="background:linear-gradient(180deg,#ffffff 0%,#eaf5ff 100%)">
    <div class="container">
        <h2 class="text-center">Alur penggunaan</h2>
        <div class="row" style="margin-top:25px">
            <div class="col-md-3"><div class="feature-box text-center"><h4>1. Login</h4><p>Masuk sesuai akun.</p></div></div>
            <div class="col-md-3"><div class="feature-box text-center"><h4>2. Catat</h4><p>Catat item masuk, keluar, atau ajuan.</p></div></div>
            <div class="col-md-3"><div class="feature-box text-center"><h4>3. Verifikasi</h4><p>Admin cek stok, data, dan ajuan.</p></div></div>
            <div class="col-md-3"><div class="feature-box text-center"><h4>4. Laporan</h4><p>Laporan siap dipakai untuk evaluasi.</p></div></div>
        </div>
    </div>
</section>
<footer class="text-center" style="padding:28px;color:#1e4f87;background:#e0f2fe">PT. KSI Home Appliances</footer>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/css/js/bootstrap.min.js"></script>
</body>
</html>
