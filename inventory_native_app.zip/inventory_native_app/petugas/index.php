<?php
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/sesi_petugas.php';
$modul = isset($_GET['m']) ? $_GET['m'] : 'dashboard';
$allowed = ['dashboard', 'itemMasuk', 'itemKeluar', 'ajuan', 'item'];
if (!in_array($modul, $allowed, true)) {
    $modul = 'dashboard';
}
include __DIR__ . '/modul/' . $modul . '.php';
