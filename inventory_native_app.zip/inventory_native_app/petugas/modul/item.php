<?php
$active = 'item';
$page_title = 'Data Item';
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
$where = '';
if ($q !== '') {
    $safeQ = mysqli_real_escape_string($koneksi, $q);
    $where = "WHERE b.kode_item LIKE '%$safeQ%' OR b.nama_item LIKE '%$safeQ%' OR r.nama_rak LIKE '%$safeQ%' OR b.status LIKE '%$safeQ%'";
}
$rows = fetch_all("SELECT b.*, r.nama_rak FROM tb_item b LEFT JOIN tb_rak r ON b.id_rak=r.id_rak $where ORDER BY b.nama_item ASC");
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card">
    <h4>Data Item Gudang</h4>
    <p class="text-muted">Daftar item gudang dan kondisi stok saat ini.</p>

    <form method="get" class="row" style="margin:14px 0 6px">
        <input type="hidden" name="m" value="item">
        <div class="col-md-9 form-group">
            <label>Cari Item</label>
            <input class="form-control" name="q" value="<?php echo esc($q); ?>" placeholder="Cari kode, nama item, rak, atau status...">
        </div>
        <div class="col-md-3 form-group">
            <label>&nbsp;</label>
            <div class="btn-group btn-block">
                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Cari</button>
                <?php if ($q !== ''): ?><a class="btn btn-default" href="index.php?m=item">Reset</a><?php endif; ?>
            </div>
        </div>
    </form>
    <?php if ($q !== ''): ?><p class="text-muted">Hasil pencarian untuk "<?php echo esc($q); ?>": <?php echo count($rows); ?> data.</p><?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead><tr><th>Kode</th><th>Item</th><th>Rak</th><th>Stok</th><th>Stok Minimum</th><th>Status</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-center text-muted">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                <?php foreach($rows as $row): ?>
                    <tr>
                        <td><?php echo esc($row['kode_item']); ?></td>
                        <td><?php echo esc($row['nama_item']); ?></td>
                        <td><?php echo esc($row['nama_rak']); ?></td>
                        <td><?php echo (int)$row['stok']; ?></td>
                        <td><?php echo (int)$row['stok_minimum']; ?></td>
                        <td><?php echo $row['stok'] <= $row['stok_minimum'] ? '<span class="label label-danger">Minimum</span>' : '<span class="label label-success">Aman</span>'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
