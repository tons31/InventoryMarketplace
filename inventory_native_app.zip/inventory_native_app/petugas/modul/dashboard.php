<?php
$active = 'dashboard';
$page_title = 'Dashboard Petugas';
$idPetugas = (int) $_SESSION['id_petugas'];
list($startMonth, $endMonth) = current_month_range();

$profile = fetch_one("SELECT * FROM tb_petugas WHERE id_petugas = $idPetugas");
$masuk = (int) (fetch_one("SELECT COUNT(*) total FROM tb_item_masuk WHERE input_role='petugas' AND input_by=$idPetugas")['total'] ?? 0);
$keluar = (int) (fetch_one("SELECT COUNT(*) total FROM tb_item_keluar WHERE input_role='petugas' AND input_by=$idPetugas")['total'] ?? 0);
$qtyMasukBulan = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_masuk WHERE input_role='petugas' AND input_by=$idPetugas AND tanggal BETWEEN '$startMonth' AND '$endMonth'")['total'] ?? 0);
$qtyKeluarBulan = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_keluar WHERE input_role='petugas' AND input_by=$idPetugas AND tanggal BETWEEN '$startMonth' AND '$endMonth'")['total'] ?? 0);
$masukHariIni = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_masuk WHERE input_role='petugas' AND input_by=$idPetugas AND tanggal = CURDATE()")['total'] ?? 0);
$keluarHariIni = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_keluar WHERE input_role='petugas' AND input_by=$idPetugas AND tanggal = CURDATE()")['total'] ?? 0);
$marketplaceAktif = (int) (fetch_one("SELECT COUNT(*) total FROM tb_marketplace WHERE status='aktif'")['total'] ?? 0);
$ajuanTotal = (int) (fetch_one("SELECT COUNT(*) total FROM tb_ajuan WHERE id_petugas=$idPetugas")['total'] ?? 0);
$ajuanMenunggu = (int) (fetch_one("SELECT COUNT(*) total FROM tb_ajuan WHERE id_petugas=$idPetugas AND status='menunggu'")['total'] ?? 0);
$ajuanDisetujui = (int) (fetch_one("SELECT COUNT(*) total FROM tb_ajuan WHERE id_petugas=$idPetugas AND status='disetujui'")['total'] ?? 0);
$approvalRate = safe_ratio($ajuanDisetujui, max(1, $ajuanTotal));
$itemKritis = fetch_all("SELECT nama_item, stok, stok_minimum FROM tb_item WHERE stok <= stok_minimum ORDER BY (stok - stok_minimum) ASC, stok ASC LIMIT 5");
$series = monthly_inventory_series(6, 'petugas', $idPetugas);
$lineChart = svg_line_chart($series['labels'], $series['masuk'], $series['keluar'], 'Item Masuk Saya', 'Item Keluar Saya');
$tujuanMarket = fetch_all("SELECT CONCAT(m.nama_marketplace, ' - ', m.nama_toko) tujuan_market, COALESCE(SUM(k.qty),0) total_keluar FROM tb_item_keluar k LEFT JOIN tb_marketplace m ON m.id_marketplace = k.id_marketplace WHERE k.input_role='petugas' AND k.input_by=$idPetugas GROUP BY m.id_marketplace, m.nama_marketplace, m.nama_toko ORDER BY total_keluar DESC, tujuan_market ASC LIMIT 5");
if (!$tujuanMarket) {
    $tujuanMarket = [['tujuan_market' => 'Belum ada distribusi', 'total_keluar' => 0]];
}
$marketChart = svg_bar_chart($tujuanMarket, 'tujuan_market', 'total_keluar', '#2563eb');
$aktivitasTerbaru = fetch_all("SELECT aktivitas, waktu FROM tb_log_aktivitas WHERE role_user='petugas' AND id_user=$idPetugas ORDER BY waktu DESC LIMIT 6");
$ajuanTerbaru = fetch_all("SELECT a.tanggal, b.nama_item, a.qty, a.keperluan, a.status, a.reviewed_by FROM tb_ajuan a LEFT JOIN tb_item b ON a.id_item=b.id_item WHERE a.id_petugas=$idPetugas ORDER BY a.id_ajuan DESC LIMIT 5");
$distribusiHariIni = fetch_all("SELECT b.nama_item, SUM(k.qty) total_keluar, GROUP_CONCAT(CONCAT(m.nama_marketplace, ': ', k.qty) ORDER BY m.nama_marketplace SEPARATOR ' | ') rincian FROM tb_item_keluar k LEFT JOIN tb_item b ON b.id_item = k.id_item LEFT JOIN tb_marketplace m ON m.id_marketplace = k.id_marketplace WHERE k.input_role='petugas' AND k.input_by=$idPetugas AND k.tanggal = CURDATE() GROUP BY b.id_item, b.nama_item ORDER BY total_keluar DESC, b.nama_item ASC LIMIT 5");

include __DIR__ . '/../layout_top.php';
?>

<div class="dashboard-shell dashboard-shell-petugas">
    <section class="executive-hero petugas-hero">
        <div>
            <span class="eyebrow">Dashboard Petugas</span>
            <h2 class="executive-title">Ringkasan kerja hari ini</h2>
            <p class="executive-subtitle">
                Lihat stok masuk, item keluar, stok minimum, dan status ajuan Anda.
            </p>
            <div class="executive-pills">
                <span class="exec-pill"><i class="fa fa-user"></i> <?php echo esc($profile['nama'] ?? $_SESSION['nama_petugas']); ?></span>
                <span class="exec-pill"><i class="fa fa-shopping-bag"></i> <?php echo $marketplaceAktif; ?> marketplace aktif</span>
                <span class="exec-pill"><i class="fa fa-check-circle"></i> Disetujui <?php echo number_format($approvalRate, 1); ?>%</span>
            </div>
            <div class="mini-insight-grid">
                <div class="mini-insight-card">
                    <span>Masuk hari ini</span>
                    <strong><?php echo $masukHariIni; ?></strong>
                    <small>Item masuk yang Anda catat hari ini.</small>
                </div>
                <div class="mini-insight-card">
                    <span>Keluar hari ini</span>
                    <strong><?php echo $keluarHariIni; ?></strong>
                    <small>Item keluar yang Anda catat hari ini.</small>
                </div>
                <div class="mini-insight-card">
                    <span>Ajuan menunggu</span>
                    <strong><?php echo $ajuanMenunggu; ?></strong>
                    <small>Ajuan yang belum diproses admin.</small>
                </div>
            </div>
        </div>

        <div class="hero-summary-card">
            <div class="summary-line">
                <span>Ringkasan pribadi</span>
                <strong><?php echo esc($profile['username'] ?? ''); ?></strong>
            </div>
            <div class="profile-spotlight">
                <div class="profile-spotlight-avatar">
                    <?php echo photo_tag($profile['foto'] ?? '', $profile['nama'] ?? $_SESSION['nama_petugas'], 'avatar-thumb large'); ?>
                </div>
                <div class="profile-spotlight-meta">
                    <strong><?php echo esc($profile['nama'] ?? $_SESSION['nama_petugas']); ?></strong>
                    <span>Petugas operasional gudang</span>
                </div>
            </div>
            <div class="summary-grid">
                <div>
                    <small>Masuk bulan ini</small>
                    <strong><?php echo $qtyMasukBulan; ?></strong>
                </div>
                <div>
                    <small>Keluar bulan ini</small>
                    <strong><?php echo $qtyKeluarBulan; ?></strong>
                </div>
                <div>
                    <small>Total ajuan</small>
                    <strong><?php echo $ajuanTotal; ?></strong>
                </div>
                <div>
                    <small>Disetujui</small>
                    <strong><?php echo $ajuanDisetujui; ?></strong>
                </div>
            </div>
        </div>
    </section>

    <section class="row stats-row">
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-blue">
                <small>Item masuk</small>
                <h3><?php echo $masuk; ?></h3>
                <p>Total item masuk yang Anda catat.</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-green">
                <small>Item keluar</small>
                <h3><?php echo $keluar; ?></h3>
                <p>Total item keluar yang Anda catat.</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-orange">
                <small>Ajuan menunggu</small>
                <h3><?php echo $ajuanMenunggu; ?></h3>
                <p>Ajuan yang belum diproses admin.</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-indigo">
                <small>Ajuan disetujui</small>
                <h3><?php echo number_format($approvalRate, 0); ?>%</h3>
                <p>Persentase ajuan yang disetujui.</p>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Aksi cepat</div>
        <div class="row">
            <div class="col-md-4">
                <a class="action-tile action-tile-primary" href="index.php?m=itemMasuk">
                    <div class="action-tile-icon"><i class="fa fa-arrow-circle-down"></i></div>
                    <div>
                        <strong>Item masuk</strong>
                        <p>Catat stok yang baru masuk.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a class="action-tile" href="index.php?m=itemKeluar">
                    <div class="action-tile-icon"><i class="fa fa-arrow-circle-up"></i></div>
                    <div>
                        <strong>Item keluar</strong>
                        <p>Catat item yang keluar ke marketplace.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a class="action-tile" href="index.php?m=ajuan">
                    <div class="action-tile-icon"><i class="fa fa-file-text"></i></div>
                    <div>
                        <strong>Buat atau cek ajuan</strong>
                        <p>Cek apakah ajuan sudah diproses.</p>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Ringkasan kerja</div>
        <div class="row">
            <div class="col-md-8">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">6 bulan terakhir</span>
                            <h4>Item masuk vs keluar</h4>
                        </div>
                        <span class="status-box">Aktivitas Anda</span>
                    </div>
                    <?php echo $lineChart; ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Stok minimum</span>
                            <h4>Item yang perlu dicek</h4>
                        </div>
                    </div>
                    <?php if (!$itemKritis): ?>
                        <div class="empty-state"><i class="fa fa-check-circle"></i><p>Semua stok masih aman.</p></div>
                    <?php else: ?>
                        <ul class="exec-list">
                            <?php foreach ($itemKritis as $row): ?>
                                <li>
                                    <div class="list-row-top">
                                        <strong><?php echo esc($row['nama_item']); ?></strong>
                                        <span><?php echo (int) $row['stok']; ?> / <?php echo (int) $row['stok_minimum']; ?></span>
                                    </div>
                                    <small>Cek jumlah sebelum item keluar atau ajukan kebutuhan.</small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Distribusi & ajuan</div>
        <div class="row">
            <div class="col-md-5">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Marketplace</span>
                            <h4>Distribusi per marketplace</h4>
                        </div>
                    </div>
                    <?php echo $marketChart; ?>
                </div>
            </div>
            <div class="col-md-7">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Status ajuan</span>
                            <h4>Ajuan saya</h4>
                        </div>
                    </div>
                    <?php if (!$ajuanTerbaru): ?>
                        <div class="empty-state"><i class="fa fa-inbox"></i><p>Belum ada ajuan.</p></div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped exec-table-tight">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Item</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                        <th>Dicek Oleh</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ajuanTerbaru as $row): ?>
                                        <tr>
                                            <td><?php echo format_tanggal($row['tanggal']); ?></td>
                                            <td><?php echo esc($row['nama_item'] ?: '-'); ?></td>
                                            <td><?php echo (int) $row['qty']; ?></td>
                                            <td><?php echo badge_status($row['status']); ?></td>
                                            <td><?php echo esc($row['reviewed_by'] ?: '-'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Hari ini</div>
        <div class="row">
            <div class="col-md-7">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Item keluar hari ini</span>
                            <h4>Item yang keluar hari ini</h4>
                        </div>
                    </div>
                    <?php if (!$distribusiHariIni): ?>
                        <div class="empty-state"><i class="fa fa-inbox"></i><p>Belum ada item keluar hari ini.</p></div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped exec-table-tight">
                                <thead>
                                    <tr>
                                        <th>Produk</th>
                                        <th>Total Keluar</th>
                                        <th>Rincian</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($distribusiHariIni as $row): ?>
                                        <tr>
                                            <td><?php echo esc($row['nama_item']); ?></td>
                                            <td><?php echo (int) $row['total_keluar']; ?></td>
                                            <td><?php echo esc($row['rincian']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Log saya</span>
                            <h4>Aktivitas terbaru</h4>
                        </div>
                    </div>
                    <?php if (!$aktivitasTerbaru): ?>
                        <div class="empty-state"><i class="fa fa-history"></i><p>Belum ada aktivitas.</p></div>
                    <?php else: ?>
                        <ul class="timeline-list compact">
                            <?php foreach ($aktivitasTerbaru as $row): ?>
                                <li>
                                    <div class="timeline-dot"></div>
                                    <div>
                                        <p><?php echo esc($row['aktivitas']); ?></p>
                                        <small><?php echo esc($row['waktu']); ?></small>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include __DIR__ . '/../layout_bottom.php'; ?>
