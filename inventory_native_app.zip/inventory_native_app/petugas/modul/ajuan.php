<?php
$active = 'ajuan';
$page_title = 'Ajuan Item';
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['aksi'] === 'tambah' && require_post_fields(['tanggal', 'id_item', 'qty', 'keperluan'])) {
    $tanggal = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
    $id_item = (int) $_POST['id_item'];
    $qty = (int) $_POST['qty'];
    $keperluan = mysqli_real_escape_string($koneksi, $_POST['keperluan']);
    $nama_petugas = mysqli_real_escape_string($koneksi, $_SESSION['nama_petugas']);
    mysqli_query($koneksi, "INSERT INTO tb_ajuan(tanggal,id_petugas,nama_petugas,id_item,qty,keperluan,status,created_at) VALUES('$tanggal'," . (int)$_SESSION['id_petugas'] . ",'$nama_petugas',$id_item,$qty,'$keperluan','menunggu',NOW())");
    log_activity('petugas', $_SESSION['id_petugas'], $_SESSION['nama_petugas'], 'Membuat ajuan item');
    flash_set('success', 'Ajuan berhasil dibuat.');
    redirect_to('index.php?m=ajuan');
}

$item = fetch_all("SELECT id_item, kode_item, nama_item, stok FROM tb_item ORDER BY nama_item ASC");
$idPetugas = (int) $_SESSION['id_petugas'];
$where = "WHERE a.id_petugas=$idPetugas";
if ($q !== '') {
    $safeQ = mysqli_real_escape_string($koneksi, $q);
    $where .= " AND (a.tanggal LIKE '%$safeQ%' OR b.kode_item LIKE '%$safeQ%' OR b.nama_item LIKE '%$safeQ%' OR a.qty LIKE '%$safeQ%' OR a.keperluan LIKE '%$safeQ%' OR a.status LIKE '%$safeQ%' OR a.reviewed_by LIKE '%$safeQ%')";
}
$rows = fetch_all("SELECT a.*, b.kode_item, b.nama_item FROM tb_ajuan a LEFT JOIN tb_item b ON a.id_item=b.id_item $where ORDER BY a.id_ajuan DESC");
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card">
    <h4>Buat Ajuan</h4>
    <form method="post" class="row">
        <input type="hidden" name="aksi" value="tambah">
        <div class="col-md-2 form-group"><label>Tanggal</label><input type="date" class="form-control" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required></div>
        <div class="col-md-4 form-group"><label>Cari Item</label><input type="text" class="form-control" id="cariItemAjuan" placeholder="Ketik kode atau nama item" autocomplete="off"><label style="margin-top:8px">Nama Item</label><select class="form-control" name="id_item" id="pilihItemAjuan" required><?php foreach($item as $b): ?><option value="<?php echo (int)$b['id_item']; ?>" data-keyword="<?php echo esc(strtolower($b['kode_item'] . ' ' . $b['nama_item'])); ?>"><?php echo esc($b['kode_item'] . ' - ' . $b['nama_item']); ?> (stok: <?php echo (int)$b['stok']; ?>)</option><?php endforeach; ?></select><small class="text-muted" id="infoCariItemAjuan"></small></div>
        <div class="col-md-2 form-group"><label>Jumlah</label><input type="number" class="form-control" name="qty" min="1" required></div>
        <div class="col-md-4 form-group"><label>Keperluan</label><input class="form-control" name="keperluan" placeholder="Contoh: update marketplace" required></div>
        <div class="col-md-12 text-right"><button class="btn btn-success">Ajukan</button></div>
    </form>
</div>
<script>
(function () {
    var searchInput = document.getElementById('cariItemAjuan');
    var itemSelect = document.getElementById('pilihItemAjuan');
    var infoText = document.getElementById('infoCariItemAjuan');
    if (!searchInput || !itemSelect) return;

    var allOptions = Array.prototype.map.call(itemSelect.options, function (option) {
        return {
            value: option.value,
            text: option.text,
            keyword: option.getAttribute('data-keyword') || option.text.toLowerCase()
        };
    });

    function renderOptions(keyword) {
        var q = (keyword || '').toLowerCase().trim();
        var matched = allOptions.filter(function (item) {
            return q === '' || item.keyword.indexOf(q) !== -1;
        });

        itemSelect.innerHTML = '';
        matched.forEach(function (item) {
            var option = document.createElement('option');
            option.value = item.value;
            option.text = item.text;
            option.setAttribute('data-keyword', item.keyword);
            itemSelect.appendChild(option);
        });

        if (infoText) {
            infoText.textContent = q === '' ? '' : (matched.length ? matched.length + ' item ditemukan.' : 'Item tidak ditemukan.');
        }
        itemSelect.disabled = matched.length === 0;
    }

    searchInput.addEventListener('input', function () {
        renderOptions(this.value);
    });
})();
</script>

<div class="content-card">
    <h4>Status Ajuan</h4>
    <p class="text-muted">Cari riwayat ajuan berdasarkan tanggal, kode item, nama item, jumlah, keperluan, status, atau admin yang mengecek.</p>

    <form method="get" class="row" style="margin:14px 0 6px">
        <input type="hidden" name="m" value="ajuan">
        <div class="col-md-9 form-group">
            <label>Cari Ajuan</label>
            <input class="form-control" name="q" value="<?php echo esc($q); ?>" placeholder="Cari kode item, nama item, keperluan, status, atau tanggal...">
        </div>
        <div class="col-md-3 form-group">
            <label>&nbsp;</label>
            <div class="btn-group btn-block">
                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Cari</button>
                <?php if ($q !== ''): ?><a class="btn btn-default" href="index.php?m=ajuan">Reset</a><?php endif; ?>
            </div>
        </div>
    </form>
    <?php if ($q !== ''): ?><p class="text-muted">Hasil pencarian untuk "<?php echo esc($q); ?>": <?php echo count($rows); ?> data.</p><?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead><tr><th>Tanggal</th><th>Kode Item</th><th>Item</th><th>Jumlah</th><th>Keperluan</th><th>Status</th><th>Dicek Oleh</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="7" class="text-center text-muted">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                <?php foreach($rows as $row): ?>
                    <tr>
                        <td><?php echo format_tanggal($row['tanggal']); ?></td>
                        <td><?php echo esc($row['kode_item']); ?></td>
                        <td><?php echo esc($row['nama_item']); ?></td>
                        <td><?php echo (int)$row['qty']; ?></td>
                        <td><?php echo esc($row['keperluan']); ?></td>
                        <td><?php echo badge_status($row['status']); ?></td>
                        <td><?php echo esc($row['reviewed_by'] ?: '-'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
