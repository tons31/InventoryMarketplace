<?php
$active = 'itemKeluar';
$page_title = 'Item Keluar';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['aksi'] === 'tambah' && require_post_fields(['tanggal', 'id_item', 'qty', 'id_marketplace'])) {
    $tanggal = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
    $id_item = (int) $_POST['id_item'];
    $qty = (int) $_POST['qty'];
    $id_marketplace = (int) $_POST['id_marketplace'];
    $catatan = mysqli_real_escape_string($koneksi, $_POST['catatan']);
    $stok_awal = stok_item($id_item);
    if ($stok_awal < $qty) {
        flash_set('error', 'Stok tidak cukup.');
        redirect_to('index.php?m=itemKeluar');
    }
    $market = fetch_one("SELECT nama_marketplace FROM tb_marketplace WHERE id_marketplace = $id_marketplace");
    $tujuan = mysqli_real_escape_string($koneksi, $market ? $market['nama_marketplace'] : '');
    mysqli_query($koneksi, "INSERT INTO tb_item_keluar(tanggal,id_item,qty,id_marketplace,tujuan,catatan,input_by,input_role,created_at) VALUES('$tanggal',$id_item,$qty,$id_marketplace,'$tujuan','$catatan'," . (int)$_SESSION['id_petugas'] . ",'petugas',NOW())");
    update_stok_item($id_item, $stok_awal - $qty);
    log_activity('petugas', $_SESSION['id_petugas'], $_SESSION['nama_petugas'], 'Item keluar');
    flash_set('success', 'Item keluar berhasil disimpan.');
    redirect_to('index.php?m=itemKeluar');
}
$item = fetch_all("SELECT id_item, kode_item, nama_item, stok FROM tb_item ORDER BY nama_item ASC");
$marketplaces = fetch_all("SELECT * FROM tb_marketplace WHERE status='aktif' ORDER BY nama_marketplace ASC");

$filter_tanggal = isset($_GET['filter_tanggal']) ? $_GET['filter_tanggal'] : 'semua';
$tanggal_filter = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$cari_item = isset($_GET['cari_item']) ? trim($_GET['cari_item']) : '';
$urut_tanggal = isset($_GET['urut_tanggal']) ? $_GET['urut_tanggal'] : 'desc';
$urut_sql = ($urut_tanggal === 'asc') ? 'ASC' : 'DESC';
$where = array();
$where[] = "bk.input_role='petugas' AND bk.input_by=" . (int)$_SESSION['id_petugas'];
if ($filter_tanggal === 'tanggal' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_filter)) {
    $tanggal_safe = mysqli_real_escape_string($koneksi, $tanggal_filter);
    $where[] = "bk.tanggal='$tanggal_safe'";
}
if ($filter_tanggal === 'item' && $cari_item !== '') {
    $cari_item_safe = mysqli_real_escape_string($koneksi, $cari_item);
    $where[] = "(b.kode_item LIKE '%$cari_item_safe%' OR b.nama_item LIKE '%$cari_item_safe%')";
}
$where_sql = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
$rows = fetch_all("SELECT bk.*, b.kode_item, b.nama_item, m.nama_marketplace, m.nama_toko FROM tb_item_keluar bk LEFT JOIN tb_item b ON bk.id_item=b.id_item LEFT JOIN tb_marketplace m ON bk.id_marketplace=m.id_marketplace" . $where_sql . " ORDER BY bk.tanggal $urut_sql, bk.id_keluar $urut_sql");
$filter_info = 'keseluruhan';
if ($filter_tanggal === 'tanggal' && $tanggal_filter) {
    $filter_info = 'pada ' . format_tanggal($tanggal_filter);
} elseif ($filter_tanggal === 'item' && $cari_item !== '') {
    $filter_info = 'dengan kata kunci item "' . esc($cari_item) . '"';
}
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card"><h4>Item Keluar</h4><form method="post" class="row"><input type="hidden" name="aksi" value="tambah"><div class="col-md-2 form-group"><label>Tanggal</label><input type="date" class="form-control" name="tanggal" value="<?php echo date('Y-m-d'); ?>"></div><div class="col-md-3 form-group"><label>Cari Item</label><input type="text" class="form-control" id="cariItemKeluar" placeholder="Ketik kode atau nama item" autocomplete="off"><label style="margin-top:8px">Nama Item</label><select class="form-control" name="id_item" id="pilihItemKeluar" required><?php foreach($item as $b): ?><option value="<?php echo (int)$b['id_item']; ?>" data-keyword="<?php echo esc(strtolower($b['kode_item'] . ' ' . $b['nama_item'])); ?>"><?php echo esc($b['kode_item'] . ' - ' . $b['nama_item']); ?> (stok: <?php echo (int)$b['stok']; ?>)</option><?php endforeach; ?></select><small class="text-muted" id="infoCariItemKeluar"></small></div><div class="col-md-2 form-group"><label>Jumlah</label><input type="number" class="form-control" name="qty" min="1" required></div><div class="col-md-3 form-group"><label>Marketplace Tujuan</label><select class="form-control" name="id_marketplace" required><?php foreach($marketplaces as $m): ?><option value="<?php echo (int)$m['id_marketplace']; ?>"><?php echo esc($m['nama_marketplace'] . ' - ' . $m['nama_toko']); ?></option><?php endforeach; ?></select></div><div class="col-md-2 form-group"><label>Catatan</label><input class="form-control" name="catatan"></div><div class="col-md-12 text-right"><button class="btn btn-success">Simpan</button></div></form></div>
<script>
(function () {
    var searchInput = document.getElementById('cariItemKeluar');
    var itemSelect = document.getElementById('pilihItemKeluar');
    var infoText = document.getElementById('infoCariItemKeluar');
    if (!searchInput || !itemSelect) return;

    var allOptions = Array.prototype.map.call(itemSelect.options, function (option) {
        return {
            value: option.value,
            text: option.text,
            keyword: option.getAttribute('data-keyword') || option.text.toLowerCase()
        };
    });

    function renderOptions(keyword) {
        var q = (keyword || '').toLowerCase().trim();
        var matched = allOptions.filter(function (item) {
            return q === '' || item.keyword.indexOf(q) !== -1;
        });

        itemSelect.innerHTML = '';
        matched.forEach(function (item) {
            var option = document.createElement('option');
            option.value = item.value;
            option.text = item.text;
            option.setAttribute('data-keyword', item.keyword);
            itemSelect.appendChild(option);
        });

        if (infoText) {
            infoText.textContent = q === '' ? '' : (matched.length ? matched.length + ' item ditemukan.' : 'Item tidak ditemukan.');
        }
        itemSelect.disabled = matched.length === 0;
    }

    searchInput.addEventListener('input', function () {
        renderOptions(this.value);
    });
})();
</script>
<div class="content-card"><h4>Riwayat Item Keluar</h4>
<form method="get" class="row" style="margin:10px 0 18px">
    <input type="hidden" name="m" value="itemKeluar">
    <div class="col-md-3 form-group">
        <label>Tampilkan</label>
        <select class="form-control" name="filter_tanggal" onchange="this.form.submit()">
            <option value="semua" <?php echo $filter_tanggal === 'semua' ? 'selected' : ''; ?>>Semua data</option>
            <option value="tanggal" <?php echo $filter_tanggal === 'tanggal' ? 'selected' : ''; ?>>Pilih tanggal</option>
            <option value="item" <?php echo $filter_tanggal === 'item' ? 'selected' : ''; ?>>Kode / nama item</option>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <label>Tanggal</label>
        <input type="date" class="form-control" name="tanggal" value="<?php echo esc($tanggal_filter); ?>" <?php echo $filter_tanggal === 'tanggal' ? '' : 'disabled'; ?>>
    </div>
    <div class="col-md-3 form-group">
        <label>Cari Kode / Nama Item</label>
        <input type="text" class="form-control" name="cari_item" value="<?php echo esc($cari_item); ?>" placeholder="Ketik kode atau nama item" <?php echo $filter_tanggal === 'item' ? '' : 'disabled'; ?>>
    </div>
    <div class="col-md-3 form-group">
        <label>Urutkan</label>
        <select class="form-control" name="urut_tanggal">
            <option value="desc" <?php echo $urut_tanggal === 'desc' ? 'selected' : ''; ?>>Terbaru dulu</option>
            <option value="asc" <?php echo $urut_tanggal === 'asc' ? 'selected' : ''; ?>>Terlama dulu</option>
        </select>
    </div>
    <div class="col-md-12 form-group text-right">
        <button class="btn btn-primary" type="submit">Terapkan</button>
        <a class="btn btn-default" href="index.php?m=itemKeluar">Reset</a>
    </div>
</form>
<p class="text-muted">Menampilkan <?php echo count($rows); ?> data item keluar <?php echo $filter_info; ?>.</p>
<div class="table-responsive"><table class="table table-striped"><thead><tr><th>Tanggal</th><th>Kode Item</th><th>Item</th><th>Jumlah</th><th>Marketplace</th><th>Nama Toko</th></tr></thead><tbody><?php foreach($rows as $row): ?><tr><td><?php echo format_tanggal($row['tanggal']); ?></td><td><?php echo esc($row['kode_item']); ?></td><td><?php echo esc($row['nama_item']); ?></td><td><?php echo (int)$row['qty']; ?></td><td><?php echo esc($row['nama_marketplace'] ?: $row['tujuan']); ?></td><td><?php echo esc($row['nama_toko'] ?: '-'); ?></td></tr><?php endforeach; ?><?php if (!count($rows)): ?><tr><td colspan="6" class="text-center text-muted">Data tidak ditemukan.</td></tr><?php endif; ?></tbody></table></div></div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>