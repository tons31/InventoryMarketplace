<?php
$active = 'itemMasuk';
$page_title = 'Item Masuk';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['aksi'] === 'tambah' && require_post_fields(['tanggal', 'id_item', 'qty', 'sumber'])) {
    $tanggal = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
    $id_item = (int) $_POST['id_item'];
    $qty = (int) $_POST['qty'];
    $sumber = mysqli_real_escape_string($koneksi, $_POST['sumber']);
    $catatan = mysqli_real_escape_string($koneksi, $_POST['catatan']);
    mysqli_query($koneksi, "INSERT INTO tb_item_masuk(tanggal,id_item,qty,sumber,catatan,input_by,input_role,created_at) VALUES('$tanggal',$id_item,$qty,'$sumber','$catatan'," . (int)$_SESSION['id_petugas'] . ",'petugas',NOW())");
    update_stok_item($id_item, stok_item($id_item) + $qty);
    log_activity('petugas', $_SESSION['id_petugas'], $_SESSION['nama_petugas'], 'Item masuk');
    flash_set('success', 'Item masuk berhasil disimpan.');
    redirect_to('index.php?m=itemMasuk');
}
$item = fetch_all("SELECT id_item, kode_item, nama_item FROM tb_item ORDER BY nama_item ASC");

$filter_tanggal = isset($_GET['filter_tanggal']) ? $_GET['filter_tanggal'] : 'semua';
$tanggal_filter = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$cari_item = isset($_GET['cari_item']) ? trim($_GET['cari_item']) : '';
$urut_tanggal = isset($_GET['urut_tanggal']) ? $_GET['urut_tanggal'] : 'desc';
$urut_sql = ($urut_tanggal === 'asc') ? 'ASC' : 'DESC';
$where = array();
$where[] = "bm.input_role='petugas' AND bm.input_by=" . (int)$_SESSION['id_petugas'];
if ($filter_tanggal === 'tanggal' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_filter)) {
    $tanggal_safe = mysqli_real_escape_string($koneksi, $tanggal_filter);
    $where[] = "bm.tanggal='$tanggal_safe'";
}
if ($filter_tanggal === 'item' && $cari_item !== '') {
    $cari_item_safe = mysqli_real_escape_string($koneksi, $cari_item);
    $where[] = "(b.kode_item LIKE '%$cari_item_safe%' OR b.nama_item LIKE '%$cari_item_safe%')";
}
$where_sql = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
$rows = fetch_all("SELECT bm.*, b.kode_item, b.nama_item FROM tb_item_masuk bm LEFT JOIN tb_item b ON bm.id_item=b.id_item" . $where_sql . " ORDER BY bm.tanggal $urut_sql, bm.id_masuk $urut_sql");
$filter_info = 'keseluruhan';
if ($filter_tanggal === 'tanggal' && $tanggal_filter) {
    $filter_info = 'pada ' . format_tanggal($tanggal_filter);
} elseif ($filter_tanggal === 'item' && $cari_item !== '') {
    $filter_info = 'dengan kata kunci item "' . esc($cari_item) . '"';
}
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card"><div class="row"><div class="col-md-8"><h4>Item Masuk</h4><p class="text-muted">Catat stok yang masuk ke gudang.</p></div></div><form method="post" class="row"><input type="hidden" name="aksi" value="tambah"><div class="col-md-2 form-group"><label>Tanggal</label><input type="date" class="form-control" name="tanggal" value="<?php echo date('Y-m-d'); ?>"></div><div class="col-md-3 form-group"><label>Cari Item</label><input type="text" class="form-control" id="cariItemMasuk" placeholder="Ketik kode atau nama item" autocomplete="off"><label style="margin-top:8px">Nama Item</label><select class="form-control" name="id_item" id="pilihItemMasuk" required><?php foreach($item as $b): ?><option value="<?php echo (int)$b['id_item']; ?>" data-keyword="<?php echo esc(strtolower($b['kode_item'] . ' ' . $b['nama_item'])); ?>"><?php echo esc($b['kode_item'] . ' - ' . $b['nama_item']); ?></option><?php endforeach; ?></select><small class="text-muted" id="infoCariItemMasuk"></small></div><div class="col-md-2 form-group"><label>Jumlah</label><input type="number" class="form-control" name="qty" min="1" required></div><div class="col-md-3 form-group"><label>Sumber Item</label><input class="form-control" name="sumber" placeholder="Gudang pusat / supplier / retur" required></div><div class="col-md-2 form-group"><label>Catatan</label><input class="form-control" name="catatan"></div><div class="col-md-12 text-right"><button class="btn btn-success">Simpan</button></div></form></div>
<script>
(function () {
    var searchInput = document.getElementById('cariItemMasuk');
    var itemSelect = document.getElementById('pilihItemMasuk');
    var infoText = document.getElementById('infoCariItemMasuk');
    if (!searchInput || !itemSelect) return;

    var allOptions = Array.prototype.map.call(itemSelect.options, function (option) {
        return {
            value: option.value,
            text: option.text,
            keyword: option.getAttribute('data-keyword') || option.text.toLowerCase()
        };
    });

    function renderOptions(keyword) {
        var q = (keyword || '').toLowerCase().trim();
        var matched = allOptions.filter(function (item) {
            return q === '' || item.keyword.indexOf(q) !== -1;
        });

        itemSelect.innerHTML = '';
        matched.forEach(function (item) {
            var option = document.createElement('option');
            option.value = item.value;
            option.text = item.text;
            option.setAttribute('data-keyword', item.keyword);
            itemSelect.appendChild(option);
        });

        if (infoText) {
            infoText.textContent = q === '' ? '' : (matched.length ? matched.length + ' item ditemukan.' : 'Item tidak ditemukan.');
        }
        itemSelect.disabled = matched.length === 0;
    }

    searchInput.addEventListener('input', function () {
        renderOptions(this.value);
    });
})();
</script>
<div class="content-card"><h4>Riwayat Item Masuk</h4>
<form method="get" class="row" style="margin:10px 0 18px">
    <input type="hidden" name="m" value="itemMasuk">
    <div class="col-md-3 form-group">
        <label>Tampilkan</label>
        <select class="form-control" name="filter_tanggal" onchange="this.form.submit()">
            <option value="semua" <?php echo $filter_tanggal === 'semua' ? 'selected' : ''; ?>>Semua data</option>
            <option value="tanggal" <?php echo $filter_tanggal === 'tanggal' ? 'selected' : ''; ?>>Pilih tanggal</option>
            <option value="item" <?php echo $filter_tanggal === 'item' ? 'selected' : ''; ?>>Kode / nama item</option>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <label>Tanggal</label>
        <input type="date" class="form-control" name="tanggal" value="<?php echo esc($tanggal_filter); ?>" <?php echo $filter_tanggal === 'tanggal' ? '' : 'disabled'; ?>>
    </div>
    <div class="col-md-3 form-group">
        <label>Cari Kode / Nama Item</label>
        <input type="text" class="form-control" name="cari_item" value="<?php echo esc($cari_item); ?>" placeholder="Ketik kode atau nama item" <?php echo $filter_tanggal === 'item' ? '' : 'disabled'; ?>>
    </div>
    <div class="col-md-3 form-group">
        <label>Urutkan</label>
        <select class="form-control" name="urut_tanggal">
            <option value="desc" <?php echo $urut_tanggal === 'desc' ? 'selected' : ''; ?>>Terbaru dulu</option>
            <option value="asc" <?php echo $urut_tanggal === 'asc' ? 'selected' : ''; ?>>Terlama dulu</option>
        </select>
    </div>
    <div class="col-md-12 form-group text-right">
        <button class="btn btn-primary" type="submit">Terapkan</button>
        <a class="btn btn-default" href="index.php?m=itemMasuk">Reset</a>
    </div>
</form>
<p class="text-muted">Menampilkan <?php echo count($rows); ?> data item masuk <?php echo $filter_info; ?>.</p>
<div class="table-responsive"><table class="table table-striped"><thead><tr><th>Tanggal</th><th>Kode Item</th><th>Nama Item</th><th>Jumlah</th><th>Sumber</th><th>Catatan</th></tr></thead><tbody><?php foreach($rows as $row): ?><tr><td><?php echo format_tanggal($row['tanggal']); ?></td><td><?php echo esc($row['kode_item']); ?></td><td><?php echo esc($row['nama_item']); ?></td><td><?php echo (int)$row['qty']; ?></td><td><?php echo esc($row['sumber'] ?: '-'); ?></td><td><?php echo esc($row['catatan']); ?></td></tr><?php endforeach; ?><?php if (!count($rows)): ?><tr><td colspan="6" class="text-center text-muted">Data tidak ditemukan.</td></tr><?php endif; ?></tbody></table></div></div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
