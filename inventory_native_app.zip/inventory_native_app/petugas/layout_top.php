<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$active = isset($active) ? $active : 'dashboard';
$namaPetugas = isset($_SESSION['nama_petugas']) ? $_SESSION['nama_petugas'] : 'Petugas';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc($page_title ?? 'Petugas'); ?></title>
    <link rel="stylesheet" href="../vendor/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/modern.css">
    
</head>
<body class="admin-shell">
<nav class="navbar admin-navbar">
    <div class="container-fluid">
        <div class="navbar-header"><a class="navbar-brand" href="index.php">Petugas KSI</a></div>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><i class="fa fa-user-circle"></i> <?php echo esc($namaPetugas); ?></a></li>
            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
    </div>
</nav>
<div class="container-fluid">
<div class="row">
<aside class="col-sm-3 col-md-2 admin-sidebar">
    <div class="brand-mini">Menu Petugas</div>
    <a href="index.php?m=dashboard" class="<?php echo $active === 'dashboard' ? 'active' : ''; ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
    <a href="index.php?m=itemMasuk" class="<?php echo $active === 'itemMasuk' ? 'active' : ''; ?>"><i class="fa fa-arrow-circle-down"></i> Item Masuk</a>
    <a href="index.php?m=itemKeluar" class="<?php echo $active === 'itemKeluar' ? 'active' : ''; ?>"><i class="fa fa-arrow-circle-up"></i> Item Keluar</a>
    <a href="index.php?m=ajuan" class="<?php echo $active === 'ajuan' ? 'active' : ''; ?>"><i class="fa fa-file-text"></i> Ajuan Item</a>
    <a href="index.php?m=item" class="<?php echo $active === 'item' ? 'active' : ''; ?>"><i class="fa fa-archive"></i> Data Item</a>
</aside>
<main class="col-sm-9 col-md-10 admin-content">
    <?php flash_show(); ?>
