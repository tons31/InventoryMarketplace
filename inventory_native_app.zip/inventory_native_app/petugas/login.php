<?php
require_once __DIR__ . '/../helpers.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!empty($_SESSION['petugas_login'])) {
    redirect_to('index.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!require_post_fields(['username', 'password'])) {
        flash_set('error', 'Username dan password wajib diisi.');
        redirect_to('login.php');
    }
    $username = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $row = fetch_one("SELECT * FROM tb_petugas WHERE username = '$username' LIMIT 1");
    if ($row && password_verify($_POST['password'], $row['password'])) {
        $_SESSION['petugas_login'] = true;
        $_SESSION['id_petugas'] = $row['id_petugas'];
        $_SESSION['nama_petugas'] = $row['nama'];
        $_SESSION['last_activity'] = time();
        log_activity('petugas', $row['id_petugas'], $row['nama'], 'Login petugas');
        redirect_to('index.php');
    }
    flash_set('error', 'Login gagal. Cek username atau password.');
    redirect_to('login.php');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Petugas</title>
    <link rel="stylesheet" href="../vendor/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/modern.css">
</head>
<body class="landing-shell">
<div class="container" style="max-width:480px;padding-top:80px">
    <div class="feature-box">
        <h3 class="text-center">Petugas</h3>
        <p class="text-center text-muted">Catat stok masuk, keluar, dan ajuan.</p>
        <?php flash_show(); ?>
        <form method="post">
            <div class="form-group"><label>Username</label><input type="text" class="form-control" name="username"></div>
            <div class="form-group"><label>Password</label><input type="password" class="form-control" name="password"></div>
            <button class="btn btn-primary btn-block"><i class="fa fa-sign-in"></i> Masuk</button>
            <a href="../index.php" class="btn btn-default btn-block">Kembali</a>
        </form>
        <hr>
        <p class="text-center text-muted">Hubungi admin pengelola untuk membuat akun</p>
    </div>
</div>
</body>
</html>
