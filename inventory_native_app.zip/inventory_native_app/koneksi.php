<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'inventory_ksi';

$koneksi = @mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die('Koneksi database gagal. Silakan import database/inventory_ksi.sql lalu sesuaikan koneksi.php');
}
mysqli_set_charset($koneksi, 'utf8mb4');
