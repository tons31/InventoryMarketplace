<?php
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/sesi_admin.php';
$modul = isset($_GET['m']) ? $_GET['m'] : 'dashboard';
$allowed = ['dashboard', 'admin', 'petugas', 'marketplace', 'rak', 'item', 'itemMasuk', 'itemKeluar', 'ajuan', 'laporan'];
if (!in_array($modul, $allowed, true)) {
    $modul = 'dashboard';
}
include __DIR__ . '/modul/' . $modul . '.php';
