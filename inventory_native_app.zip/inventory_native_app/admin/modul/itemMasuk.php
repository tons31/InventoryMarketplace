<?php
$active = 'itemMasuk';
$page_title = 'Item Masuk';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    flash_set('error', 'Admin hanya dapat mengecek data item masuk, tidak dapat menginput data.');
    redirect_to('index.php?m=itemMasuk');
}
$item = fetch_all("SELECT id_item, kode_item, nama_item FROM tb_item ORDER BY nama_item ASC");

$filter_tanggal = isset($_GET['filter_tanggal']) ? $_GET['filter_tanggal'] : 'semua';
$tanggal_filter = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$cari_item = isset($_GET['cari_item']) ? trim($_GET['cari_item']) : '';
$urut_tanggal = isset($_GET['urut_tanggal']) ? $_GET['urut_tanggal'] : 'desc';
$urut_sql = ($urut_tanggal === 'asc') ? 'ASC' : 'DESC';
$where = array();
if ($filter_tanggal === 'tanggal' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_filter)) {
    $tanggal_safe = mysqli_real_escape_string($koneksi, $tanggal_filter);
    $where[] = "bm.tanggal='$tanggal_safe'";
}
if ($filter_tanggal === 'item' && $cari_item !== '') {
    $cari_item_safe = mysqli_real_escape_string($koneksi, $cari_item);
    $where[] = "(b.kode_item LIKE '%$cari_item_safe%' OR b.nama_item LIKE '%$cari_item_safe%')";
}
$where_sql = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
$rows = fetch_all("SELECT bm.*, b.kode_item, b.nama_item FROM tb_item_masuk bm LEFT JOIN tb_item b ON bm.id_item=b.id_item" . $where_sql . " ORDER BY bm.tanggal $urut_sql, bm.id_masuk $urut_sql");
$filter_info = 'keseluruhan';
if ($filter_tanggal === 'tanggal' && $tanggal_filter) {
    $filter_info = 'pada ' . format_tanggal($tanggal_filter);
} elseif ($filter_tanggal === 'item' && $cari_item !== '') {
    $filter_info = 'dengan kata kunci item "' . esc($cari_item) . '"';
}
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card"><div class="row"><div class="col-md-12"><h4>Item Masuk</h4><p class="text-muted">Admin hanya dapat mengecek data item masuk. Input data dilakukan melalui akun petugas.</p></div></div>

<form method="get" class="row" style="margin:10px 0 18px">
    <input type="hidden" name="m" value="itemMasuk">
    <div class="col-md-3 form-group">
        <label>Tampilkan</label>
        <select class="form-control" name="filter_tanggal" onchange="this.form.submit()">
            <option value="semua" <?php echo $filter_tanggal === 'semua' ? 'selected' : ''; ?>>Semua data</option>
            <option value="tanggal" <?php echo $filter_tanggal === 'tanggal' ? 'selected' : ''; ?>>Pilih tanggal</option>
            <option value="item" <?php echo $filter_tanggal === 'item' ? 'selected' : ''; ?>>Kode / nama item</option>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <label>Tanggal</label>
        <input type="date" class="form-control" name="tanggal" value="<?php echo esc($tanggal_filter); ?>" <?php echo $filter_tanggal === 'tanggal' ? '' : 'disabled'; ?>>
    </div>
    <div class="col-md-3 form-group">
        <label>Cari Kode / Nama Item</label>
        <input type="text" class="form-control" name="cari_item" value="<?php echo esc($cari_item); ?>" placeholder="Ketik kode atau nama item" <?php echo $filter_tanggal === 'item' ? '' : 'disabled'; ?>>
    </div>
    <div class="col-md-3 form-group">
        <label>Urutkan</label>
        <select class="form-control" name="urut_tanggal">
            <option value="desc" <?php echo $urut_tanggal === 'desc' ? 'selected' : ''; ?>>Terbaru dulu</option>
            <option value="asc" <?php echo $urut_tanggal === 'asc' ? 'selected' : ''; ?>>Terlama dulu</option>
        </select>
    </div>
    <div class="col-md-12 form-group text-right">
        <button class="btn btn-primary" type="submit">Terapkan</button>
        <a class="btn btn-default" href="index.php?m=itemMasuk">Reset</a>
    </div>
</form>
<p class="text-muted">Menampilkan <?php echo count($rows); ?> data item masuk <?php echo $filter_info; ?>.</p>
<div class="table-responsive"><table class="table table-striped"><thead><tr><th>Tanggal</th><th>Kode Item</th><th>Item</th><th>Jumlah</th><th>Sumber</th><th>Catatan</th><th>Dicatat Oleh</th></tr></thead><tbody><?php foreach($rows as $row): ?><tr><td><?php echo format_tanggal($row['tanggal']); ?></td><td><?php echo esc($row['kode_item']); ?></td><td><?php echo esc($row['nama_item']); ?></td><td><?php echo (int)$row['qty']; ?></td><td><?php echo esc($row['sumber'] ?: '-'); ?></td><td><?php echo esc($row['catatan']); ?></td><td><?php echo esc($row['input_role']); ?></td></tr><?php endforeach; ?><?php if (!count($rows)): ?><tr><td colspan="7" class="text-center text-muted">Data tidak ditemukan.</td></tr><?php endif; ?></tbody></table></div></div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
