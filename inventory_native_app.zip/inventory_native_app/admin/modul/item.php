<?php
$active = 'item';
$page_title = 'Data Item';
$edit_id = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah' && require_post_fields(['kode_item', 'nama_item', 'id_rak', 'stok_minimum'])) {
        $kode = mysqli_real_escape_string($koneksi, $_POST['kode_item']);
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama_item']);
        $id_rak = (int) $_POST['id_rak'];
        $stok = (int) ($_POST['stok'] ?? 0);
        $stok_min = (int) $_POST['stok_minimum'];
        $status = mysqli_real_escape_string($koneksi, $_POST['status'] ?: 'aktif');
        mysqli_query($koneksi, "INSERT INTO tb_item(kode_item,nama_item,id_rak,stok,stok_minimum,status,created_at,updated_at) VALUES('$kode','$nama',$id_rak,$stok,$stok_min,'$status',NOW(),NOW())");
        log_activity('admin', $_SESSION['id_admin'], $_SESSION['nama_admin'], 'Menambah data item');
        flash_set('success', 'Item berhasil ditambahkan.');
        redirect_to('index.php?m=item');
    }
    if ($_POST['aksi'] === 'update' && require_post_fields(['id', 'kode_item', 'nama_item', 'id_rak', 'stok_minimum'])) {
        $id = (int) $_POST['id'];
        $kode = mysqli_real_escape_string($koneksi, $_POST['kode_item']);
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama_item']);
        $id_rak = (int) $_POST['id_rak'];
        $stok = (int) ($_POST['stok'] ?? 0);
        $stok_min = (int) $_POST['stok_minimum'];
        $status = mysqli_real_escape_string($koneksi, $_POST['status'] ?: 'aktif');
        mysqli_query($koneksi, "UPDATE tb_item SET kode_item='$kode', nama_item='$nama', id_rak=$id_rak, stok=$stok, stok_minimum=$stok_min, status='$status', updated_at=NOW() WHERE id_item = $id");
        log_activity('admin', $_SESSION['id_admin'], $_SESSION['nama_admin'], 'Memperbarui data item');
        flash_set('success', 'Item berhasil diperbarui.');
        redirect_to('index.php?m=item');
    }
    if ($_POST['aksi'] === 'hapus') {
        mysqli_query($koneksi, "DELETE FROM tb_item WHERE id_item = " . (int) $_POST['id']);
        flash_set('success', 'Item berhasil dihapus.');
        redirect_to('index.php?m=item');
    }
}

$raks = fetch_all("SELECT * FROM tb_rak ORDER BY nama_rak ASC");
$editData = $edit_id ? fetch_one("SELECT * FROM tb_item WHERE id_item = $edit_id") : null;
$where = '';
if ($q !== '') {
    $safeQ = mysqli_real_escape_string($koneksi, $q);
    $where = "WHERE b.kode_item LIKE '%$safeQ%' OR b.nama_item LIKE '%$safeQ%' OR r.nama_rak LIKE '%$safeQ%' OR b.status LIKE '%$safeQ%'";
}
$rows = fetch_all("SELECT b.*, r.nama_rak FROM tb_item b LEFT JOIN tb_rak r ON b.id_rak=r.id_rak $where ORDER BY b.id_item DESC");
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card">
    <div class="row">
        <div class="col-md-7"><h4>Data Item</h4><p class="text-muted">Kelola kode, nama, rak, stok, dan batas minimum item.</p></div>
        <div class="col-md-5 text-right"><button class="btn btn-primary" data-toggle="collapse" data-target="#formItem">Tambah Item</button></div>
    </div>

    <form method="get" class="row" style="margin:14px 0 6px">
        <input type="hidden" name="m" value="item">
        <div class="col-md-9 form-group">
            <label>Cari Item</label>
            <input class="form-control" name="q" value="<?php echo esc($q); ?>" placeholder="Cari kode, nama item, rak, atau status...">
        </div>
        <div class="col-md-3 form-group">
            <label>&nbsp;</label>
            <div class="btn-group btn-block">
                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Cari</button>
                <?php if ($q !== ''): ?><a class="btn btn-default" href="index.php?m=item">Reset</a><?php endif; ?>
            </div>
        </div>
    </form>
    <?php if ($q !== ''): ?><p class="text-muted">Hasil pencarian untuk "<?php echo esc($q); ?>": <?php echo count($rows); ?> data.</p><?php endif; ?>

    <div id="formItem" class="collapse <?php echo $editData ? 'in' : ''; ?>" style="margin-top:18px">
        <form method="post" class="row">
            <input type="hidden" name="aksi" value="<?php echo $editData ? 'update' : 'tambah'; ?>">
            <?php if ($editData): ?><input type="hidden" name="id" value="<?php echo (int) $editData['id_item']; ?>"><?php endif; ?>
            <div class="col-md-3 form-group"><label>Kode Item</label><input class="form-control" name="kode_item" value="<?php echo esc($editData['kode_item'] ?? ''); ?>"></div>
            <div class="col-md-4 form-group"><label>Nama Item</label><input class="form-control" name="nama_item" value="<?php echo esc($editData['nama_item'] ?? ''); ?>"></div>
            <div class="col-md-2 form-group"><label>Rak</label><select class="form-control" name="id_rak"><?php foreach($raks as $r): ?><option value="<?php echo (int)$r['id_rak']; ?>" <?php echo selected_attr($editData['id_rak'] ?? '', $r['id_rak']); ?>><?php echo esc($r['nama_rak']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-1 form-group"><label>Stok</label><input type="number" class="form-control" name="stok" value="<?php echo esc($editData['stok'] ?? 0); ?>"></div>
            <div class="col-md-1 form-group"><label>Min</label><input type="number" class="form-control" name="stok_minimum" value="<?php echo esc($editData['stok_minimum'] ?? 5); ?>"></div>
            <div class="col-md-1 form-group"><label>Status</label><select class="form-control" name="status"><option value="aktif" <?php echo selected_attr($editData['status'] ?? 'aktif', 'aktif'); ?>>Aktif</option><option value="nonaktif" <?php echo selected_attr($editData['status'] ?? '', 'nonaktif'); ?>>Nonaktif</option></select></div>
            <div class="col-md-12 text-right"><button class="btn btn-success">Simpan</button></div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead><tr><th>Kode</th><th>Item</th><th>Rak</th><th>Stok</th><th>Min</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="7" class="text-center text-muted">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                <?php foreach($rows as $row): ?>
                    <tr>
                        <td><?php echo esc($row['kode_item']); ?></td>
                        <td><?php echo esc($row['nama_item']); ?></td>
                        <td><?php echo esc($row['nama_rak']); ?></td>
                        <td><?php echo (int)$row['stok']; ?></td>
                        <td><?php echo (int)$row['stok_minimum']; ?></td>
                        <td><?php echo badge_status($row['status']); ?></td>
                        <td><a class="btn btn-xs btn-info" href="index.php?m=item&edit=<?php echo (int)$row['id_item']; ?><?php echo $q !== '' ? '&q=' . urlencode($q) : ''; ?>">Edit</a> <form method="post" style="display:inline"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?php echo (int)$row['id_item']; ?>"><button class="btn btn-xs btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</button></form></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
