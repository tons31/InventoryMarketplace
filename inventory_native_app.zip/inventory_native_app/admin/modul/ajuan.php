<?php
$active = 'ajuan';
$page_title = 'Ajuan Item';
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    $id = (int) $_POST['id'];
    if ($_POST['aksi'] === 'setujui') {
        mysqli_query($koneksi, "UPDATE tb_ajuan SET status='disetujui', reviewed_by='" . mysqli_real_escape_string($koneksi, $_SESSION['nama_admin']) . "', reviewed_at=NOW() WHERE id_ajuan = $id");
        log_activity('admin', $_SESSION['id_admin'], $_SESSION['nama_admin'], 'Menyetujui ajuan item');
        flash_set('success', 'Ajuan berhasil disetujui.');
        redirect_to('index.php?m=ajuan' . ($q !== '' ? '&q=' . urlencode($q) : ''));
    }
    if ($_POST['aksi'] === 'tolak') {
        mysqli_query($koneksi, "UPDATE tb_ajuan SET status='ditolak', reviewed_by='" . mysqli_real_escape_string($koneksi, $_SESSION['nama_admin']) . "', reviewed_at=NOW() WHERE id_ajuan = $id");
        log_activity('admin', $_SESSION['id_admin'], $_SESSION['nama_admin'], 'Menolak ajuan item');
        flash_set('warning', 'Ajuan berhasil ditolak.');
        redirect_to('index.php?m=ajuan' . ($q !== '' ? '&q=' . urlencode($q) : ''));
    }
}

$where = '';
if ($q !== '') {
    $safeQ = mysqli_real_escape_string($koneksi, $q);
    $where = "WHERE a.tanggal LIKE '%$safeQ%' OR a.nama_petugas LIKE '%$safeQ%' OR b.kode_item LIKE '%$safeQ%' OR b.nama_item LIKE '%$safeQ%' OR a.qty LIKE '%$safeQ%' OR a.keperluan LIKE '%$safeQ%' OR a.status LIKE '%$safeQ%' OR a.reviewed_by LIKE '%$safeQ%'";
}
$rows = fetch_all("SELECT a.*, b.kode_item, b.nama_item FROM tb_ajuan a LEFT JOIN tb_item b ON a.id_item = b.id_item $where ORDER BY a.id_ajuan DESC");
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card">
    <h4>Daftar Ajuan</h4>
    <p class="text-muted">Cari ajuan berdasarkan tanggal, petugas, kode item, nama item, jumlah, keperluan, status, atau admin yang mengecek.</p>

    <form method="get" class="row" style="margin:14px 0 6px">
        <input type="hidden" name="m" value="ajuan">
        <div class="col-md-9 form-group">
            <label>Cari Ajuan</label>
            <input class="form-control" name="q" value="<?php echo esc($q); ?>" placeholder="Cari petugas, kode item, nama item, keperluan, status, atau tanggal...">
        </div>
        <div class="col-md-3 form-group">
            <label>&nbsp;</label>
            <div class="btn-group btn-block">
                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Cari</button>
                <?php if ($q !== ''): ?><a class="btn btn-default" href="index.php?m=ajuan">Reset</a><?php endif; ?>
            </div>
        </div>
    </form>
    <?php if ($q !== ''): ?><p class="text-muted">Hasil pencarian untuk "<?php echo esc($q); ?>": <?php echo count($rows); ?> data.</p><?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead><tr><th>Tanggal</th><th>Petugas</th><th>Kode Item</th><th>Item</th><th>Jumlah</th><th>Keperluan</th><th>Status</th><th>Dicek Oleh</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="9" class="text-center text-muted">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                <?php foreach($rows as $row): ?>
                    <tr>
                        <td><?php echo format_tanggal($row['tanggal']); ?></td>
                        <td><?php echo esc($row['nama_petugas']); ?></td>
                        <td><?php echo esc($row['kode_item']); ?></td>
                        <td><?php echo esc($row['nama_item']); ?></td>
                        <td><?php echo (int)$row['qty']; ?></td>
                        <td><?php echo esc($row['keperluan']); ?></td>
                        <td><?php echo badge_status($row['status']); ?></td>
                        <td><?php echo esc($row['reviewed_by'] ?: '-'); ?></td>
                        <td>
                            <?php if ($row['status'] === 'menunggu'): ?>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="id" value="<?php echo (int)$row['id_ajuan']; ?>">
                                    <button class="btn btn-xs btn-success" name="aksi" value="setujui">Setujui</button>
                                </form>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="id" value="<?php echo (int)$row['id_ajuan']; ?>">
                                    <button class="btn btn-xs btn-danger" name="aksi" value="tolak">Tolak</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">Selesai</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
