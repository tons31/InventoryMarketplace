<?php
$active = 'dashboard';
$page_title = 'Dashboard Admin';
list($bulan_mulai, $bulan_selesai) = current_month_range();

$total_admin = (int) (fetch_one("SELECT COUNT(*) total FROM tb_admin")['total'] ?? 0);
$total_petugas = (int) (fetch_one("SELECT COUNT(*) total FROM tb_petugas")['total'] ?? 0);
$total_item = (int) (fetch_one("SELECT COUNT(*) total FROM tb_item")['total'] ?? 0);
$total_stok = (int) (fetch_one("SELECT COALESCE(SUM(stok),0) total FROM tb_item")['total'] ?? 0);
$total_marketplace = (int) (fetch_one("SELECT COUNT(*) total FROM tb_marketplace WHERE status='aktif'")['total'] ?? 0);
$total_ajuan_menunggu = (int) (fetch_one("SELECT COUNT(*) total FROM tb_ajuan WHERE status='menunggu'")['total'] ?? 0);
$total_ajuan_disetujui = (int) (fetch_one("SELECT COUNT(*) total FROM tb_ajuan WHERE status='disetujui' AND DATE_FORMAT(created_at,'%Y-%m') = DATE_FORMAT(CURDATE(),'%Y-%m')")['total'] ?? 0);
$total_ajuan_ditolak = (int) (fetch_one("SELECT COUNT(*) total FROM tb_ajuan WHERE status='ditolak' AND DATE_FORMAT(created_at,'%Y-%m') = DATE_FORMAT(CURDATE(),'%Y-%m')")['total'] ?? 0);
$total_kritis = (int) (fetch_one("SELECT COUNT(*) total FROM tb_item WHERE stok <= stok_minimum")['total'] ?? 0);
$keluar_bulan = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_keluar WHERE tanggal BETWEEN '$bulan_mulai' AND '$bulan_selesai'")['total'] ?? 0);
$masuk_bulan = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_masuk WHERE tanggal BETWEEN '$bulan_mulai' AND '$bulan_selesai'")['total'] ?? 0);
$masuk_hari_ini = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_masuk WHERE tanggal = CURDATE()")['total'] ?? 0);
$keluar_hari_ini = (int) (fetch_one("SELECT COALESCE(SUM(qty),0) total FROM tb_item_keluar WHERE tanggal = CURDATE()")['total'] ?? 0);
$aktivitas_hari_ini = (int) (fetch_one("SELECT COUNT(*) total FROM tb_log_aktivitas WHERE DATE(waktu)=CURDATE()")['total'] ?? 0);
$stok_aman = max(0, $total_item - $total_kritis);
$approval_rate = safe_ratio($total_ajuan_disetujui, max(1, $total_ajuan_disetujui + $total_ajuan_ditolak));
$persen_kritis = safe_ratio($total_kritis, max(1, $total_item));
$persen_keluar = max(8, min(100, safe_ratio($keluar_bulan, max(1, $total_stok))));

$series = monthly_inventory_series(6);
$lineChart = svg_line_chart($series['labels'], $series['masuk'], $series['keluar'], 'Item Masuk', 'Item Keluar');

$stok_minimum = fetch_all("SELECT nama_item, stok, stok_minimum FROM tb_item WHERE stok <= stok_minimum ORDER BY (stok - stok_minimum) ASC, stok ASC LIMIT 5");
$marketplace_perf = fetch_all("SELECT CONCAT(m.nama_marketplace, ' - ', m.nama_toko) nama_marketplace, COALESCE(SUM(k.qty),0) total_keluar FROM tb_marketplace m LEFT JOIN tb_item_keluar k ON k.id_marketplace = m.id_marketplace WHERE m.status='aktif' GROUP BY m.id_marketplace, m.nama_marketplace, m.nama_toko ORDER BY total_keluar DESC, m.nama_marketplace ASC LIMIT 5");
if (!$marketplace_perf) {
    $marketplace_perf = [['nama_marketplace' => 'Belum ada distribusi', 'total_keluar' => 0]];
}
$marketplaceChart = svg_bar_chart($marketplace_perf, 'nama_marketplace', 'total_keluar', '#0ea5e9');

$ajuan_terbaru = fetch_all("SELECT a.id_ajuan, a.tanggal, a.nama_petugas, b.nama_item, a.qty, a.keperluan, a.status FROM tb_ajuan a LEFT JOIN tb_item b ON b.id_item = a.id_item ORDER BY a.id_ajuan DESC LIMIT 6");
$aktivitas = fetch_all("SELECT nama_user, aktivitas, waktu FROM tb_log_aktivitas ORDER BY waktu DESC LIMIT 7");

include __DIR__ . '/../layout_top.php';
?>

<div class="dashboard-shell dashboard-shell-admin">
    <section class="executive-hero">
        <div>
            <span class="eyebrow">Dashboard Admin</span>
            <h2 class="executive-title">Pantau stok dan aktivitas gudang</h2>
            <p class="executive-subtitle">
                Lihat kondisi stok, ajuan, aktivitas hari ini, dan marketplace aktif dalam satu halaman.
            </p>
            <div class="executive-pills">
                <span class="exec-pill"><i class="fa fa-calendar"></i> Periode <?php echo esc(date('F Y')); ?></span>
                <span class="exec-pill"><i class="fa fa-users"></i> <?php echo $total_admin + $total_petugas; ?> pengguna aktif</span>
                <span class="exec-pill"><i class="fa fa-shopping-bag"></i> <?php echo $total_marketplace; ?> marketplace aktif</span>
            </div>
            <div class="mini-insight-grid">
                <div class="mini-insight-card">
                    <span>Perlu dicek</span>
                    <strong><?php echo $total_kritis; ?> SKU</strong>
                    <small>Item sudah menyentuh batas minimum.</small>
                </div>
                <div class="mini-insight-card">
                    <span>Ajuan bulan ini</span>
                    <strong><?php echo number_format($approval_rate, 1); ?>%</strong>
                    <small>Ajuan yang disetujui bulan ini.</small>
                </div>
                <div class="mini-insight-card">
                    <span>Aktivitas hari ini</span>
                    <strong><?php echo $aktivitas_hari_ini; ?></strong>
                    <small>Aktivitas yang tercatat hari ini.</small>
                </div>
            </div>
        </div>

        <div class="hero-summary-card">
            <div class="summary-line">
                <span>Ringkasan gudang</span>
                <strong><?php echo $keluar_bulan; ?> unit</strong>
            </div>
            <div class="progress executive-progress"><span style="width: <?php echo $persen_keluar; ?>%"></span></div>
            <div class="summary-grid">
                <div>
                    <small>Masuk hari ini</small>
                    <strong><?php echo $masuk_hari_ini; ?></strong>
                </div>
                <div>
                    <small>Keluar hari ini</small>
                    <strong><?php echo $keluar_hari_ini; ?></strong>
                </div>
                <div>
                    <small>Ajuan menunggu</small>
                    <strong><?php echo $total_ajuan_menunggu; ?></strong>
                </div>
                <div>
                    <small>SKU aman</small>
                    <strong><?php echo $stok_aman; ?></strong>
                </div>
            </div>
        </div>
    </section>

    <section class="row stats-row">
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-blue">
                <small>Stok total</small>
                <h3><?php echo $total_stok; ?></h3>
                <p>Total unit tersedia di gudang.</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-orange">
                <small>Stok minimum</small>
                <h3><?php echo $total_kritis; ?></h3>
                <p><?php echo number_format($persen_kritis, 1); ?>% dari total SKU perlu dicek.</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-indigo">
                <small>Ajuan menunggu</small>
                <h3><?php echo $total_ajuan_menunggu; ?></h3>
                <p>Ajuan yang belum diproses.</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="exec-stat-card stat-green">
                <small>Item keluar bulan ini</small>
                <h3><?php echo $keluar_bulan; ?></h3>
                <p>Total item keluar bulan ini.</p>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Aksi cepat</div>
        <div class="row">
            <div class="col-md-4">
                <a class="action-tile action-tile-primary" href="index.php?m=ajuan">
                    <div class="action-tile-icon"><i class="fa fa-file-text"></i></div>
                    <div>
                        <strong>Cek ajuan item</strong>
                        <p>Setujui atau tolak ajuan yang masuk.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a class="action-tile" href="index.php?m=item">
                    <div class="action-tile-icon"><i class="fa fa-archive"></i></div>
                    <div>
                        <strong>Cek stok item</strong>
                        <p>Lihat item yang stoknya mulai rendah.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a class="action-tile" href="index.php?m=laporan">
                    <div class="action-tile-icon"><i class="fa fa-bar-chart"></i></div>
                    <div>
                        <strong>Lihat laporan</strong>
                        <p>Cek item masuk, keluar, dan alokasi stok.</p>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Ringkasan aktivitas</div>
        <div class="row">
            <div class="col-md-8">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">6 bulan terakhir</span>
                            <h4>Item masuk vs keluar</h4>
                        </div>
                        <span class="status-box">Tren gudang</span>
                    </div>
                    <?php echo $lineChart; ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Stok minimum</span>
                            <h4>Item yang perlu dicek</h4>
                        </div>
                        <span class="mini-badge mini-badge-danger"><?php echo $total_kritis; ?> item</span>
                    </div>
                    <?php if (!$stok_minimum): ?>
                        <div class="empty-state"><i class="fa fa-check-circle"></i><p>Semua stok masih aman.</p></div>
                    <?php else: ?>
                        <ul class="exec-list">
                            <?php foreach ($stok_minimum as $row): ?>
                                <li>
                                    <div class="list-row-top">
                                        <strong><?php echo esc($row['nama_item']); ?></strong>
                                        <span><?php echo (int) $row['stok']; ?> / <?php echo (int) $row['stok_minimum']; ?></span>
                                    </div>
                                    <small>Cek stok sebelum distribusi.</small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Distribusi & ajuan</div>
        <div class="row">
            <div class="col-md-5">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Marketplace</span>
                            <h4>Distribusi per marketplace</h4>
                        </div>
                    </div>
                    <?php echo $marketplaceChart; ?>
                </div>
            </div>
            <div class="col-md-7">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Ajuan terbaru</span>
                            <h4>Ajuan masuk</h4>
                        </div>
                    </div>
                    <?php if (!$ajuan_terbaru): ?>
                        <div class="empty-state"><i class="fa fa-inbox"></i><p>Belum ada ajuan.</p></div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped exec-table-tight">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Petugas</th>
                                        <th>Item</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ajuan_terbaru as $row): ?>
                                        <tr>
                                            <td><?php echo format_tanggal($row['tanggal']); ?></td>
                                            <td><?php echo esc($row['nama_petugas']); ?></td>
                                            <td><?php echo esc($row['nama_item'] ?: '-'); ?></td>
                                            <td><?php echo (int) $row['qty']; ?></td>
                                            <td><?php echo badge_status($row['status']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <div class="section-label">Aktivitas</div>
        <div class="row">
            <div class="col-md-12">
                <div class="content-card executive-card">
                    <div class="card-head-flex">
                        <div>
                            <span class="card-kicker">Log</span>
                            <h4>Aktivitas terbaru</h4>
                        </div>
                    </div>
                    <?php if (!$aktivitas): ?>
                        <div class="empty-state"><i class="fa fa-history"></i><p>Belum ada aktivitas.</p></div>
                    <?php else: ?>
                        <ul class="timeline-list">
                            <?php foreach ($aktivitas as $row): ?>
                                <li>
                                    <div class="timeline-dot"></div>
                                    <div>
                                        <strong><?php echo esc($row['nama_user']); ?></strong>
                                        <p><?php echo esc($row['aktivitas']); ?></p>
                                        <small><?php echo esc($row['waktu']); ?></small>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include __DIR__ . '/../layout_bottom.php'; ?>
