<?php
$active = 'rak';
$page_title = 'Rak';
$edit_id = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah' && require_post_fields(['kode_rak', 'nama_rak'])) {
        $kode = mysqli_real_escape_string($koneksi, $_POST['kode_rak']);
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama_rak']);
        mysqli_query($koneksi, "INSERT INTO tb_rak(kode_rak,nama_rak,created_at) VALUES('$kode','$nama',NOW())");
        flash_set('success', 'Rak berhasil ditambahkan.');
        redirect_to('index.php?m=rak');
    }
    if ($_POST['aksi'] === 'update' && require_post_fields(['id', 'kode_rak', 'nama_rak'])) {
        $id = (int) $_POST['id'];
        $kode = mysqli_real_escape_string($koneksi, $_POST['kode_rak']);
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama_rak']);
        mysqli_query($koneksi, "UPDATE tb_rak SET kode_rak='$kode', nama_rak='$nama' WHERE id_rak = $id");
        flash_set('success', 'Rak berhasil diperbarui.');
        redirect_to('index.php?m=rak');
    }
    if ($_POST['aksi'] === 'hapus') {
        mysqli_query($koneksi, "DELETE FROM tb_rak WHERE id_rak = " . (int) $_POST['id']);
        flash_set('success', 'Rak berhasil dihapus.');
        redirect_to('index.php?m=rak');
    }
}

$editData = $edit_id ? fetch_one("SELECT * FROM tb_rak WHERE id_rak = $edit_id") : null;
$where = '';
if ($q !== '') {
    $safeQ = mysqli_real_escape_string($koneksi, $q);
    $where = "WHERE kode_rak LIKE '%$safeQ%' OR nama_rak LIKE '%$safeQ%'";
}
$rows = fetch_all("SELECT * FROM tb_rak $where ORDER BY id_rak DESC");
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card">
    <div class="row">
        <div class="col-md-6"><h4>Data Rak</h4></div>
        <div class="col-md-6 text-right"><button class="btn btn-primary" data-toggle="collapse" data-target="#formRak"><?php echo $editData ? 'Tambah Rak Baru' : 'Tambah Rak'; ?></button></div>
    </div>

    <form method="get" class="row" style="margin:14px 0 6px">
        <input type="hidden" name="m" value="rak">
        <div class="col-md-9 form-group">
            <label>Cari Rak</label>
            <input class="form-control" name="q" value="<?php echo esc($q); ?>" placeholder="Cari kode rak atau nama rak...">
        </div>
        <div class="col-md-3 form-group">
            <label>&nbsp;</label>
            <div class="btn-group btn-block">
                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Cari</button>
                <?php if ($q !== ''): ?><a class="btn btn-default" href="index.php?m=rak">Reset</a><?php endif; ?>
            </div>
        </div>
    </form>
    <?php if ($q !== ''): ?><p class="text-muted">Hasil pencarian untuk "<?php echo esc($q); ?>": <?php echo count($rows); ?> data.</p><?php endif; ?>

    <div id="formRak" class="collapse <?php echo $editData ? 'in' : ''; ?>" style="margin-top:18px">
        <form method="post" class="row">
            <input type="hidden" name="aksi" value="<?php echo $editData ? 'update' : 'tambah'; ?>">
            <?php if ($editData): ?><input type="hidden" name="id" value="<?php echo (int) $editData['id_rak']; ?>"><?php endif; ?>
            <div class="col-md-4 form-group"><label>Kode Rak</label><input class="form-control" name="kode_rak" value="<?php echo esc($editData['kode_rak'] ?? ''); ?>"></div>
            <div class="col-md-6 form-group"><label>Nama Rak</label><input class="form-control" name="nama_rak" value="<?php echo esc($editData['nama_rak'] ?? ''); ?>"></div>
            <div class="col-md-2 form-group"><label>&nbsp;</label><button class="btn btn-success btn-block">Simpan</button></div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead><tr><th>ID</th><th>Kode</th><th>Nama Rak</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="4" class="text-center text-muted">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?php echo (int)$row['id_rak']; ?></td>
                        <td><?php echo esc($row['kode_rak']); ?></td>
                        <td><?php echo esc($row['nama_rak']); ?></td>
                        <td><a class="btn btn-xs btn-info" href="index.php?m=rak&edit=<?php echo (int)$row['id_rak']; ?><?php echo $q !== '' ? '&q=' . urlencode($q) : ''; ?>">Edit</a> <form method="post" style="display:inline"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?php echo (int)$row['id_rak']; ?>"><button class="btn btn-xs btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</button></form></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
