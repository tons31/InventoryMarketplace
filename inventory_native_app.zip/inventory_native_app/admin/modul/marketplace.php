<?php
$active = 'marketplace';
$page_title = 'Marketplace';
$edit_id = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah' && require_post_fields(['nama_marketplace', 'nama_toko'])) {
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama_marketplace']);
        $nama_toko = mysqli_real_escape_string($koneksi, $_POST['nama_toko']);
        $status = mysqli_real_escape_string($koneksi, $_POST['status'] ?: 'aktif');
        mysqli_query($koneksi, "INSERT INTO tb_marketplace(nama_marketplace,nama_toko,status,created_at) VALUES('$nama','$nama_toko','$status',NOW())");
        flash_set('success', 'Marketplace berhasil ditambahkan.');
        redirect_to('index.php?m=marketplace');
    }
    if ($_POST['aksi'] === 'update' && require_post_fields(['id', 'nama_marketplace', 'nama_toko'])) {
        $id = (int) $_POST['id'];
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama_marketplace']);
        $nama_toko = mysqli_real_escape_string($koneksi, $_POST['nama_toko']);
        $status = mysqli_real_escape_string($koneksi, $_POST['status'] ?: 'aktif');
        mysqli_query($koneksi, "UPDATE tb_marketplace SET nama_marketplace='$nama', nama_toko='$nama_toko', status='$status' WHERE id_marketplace = $id");
        flash_set('success', 'Marketplace berhasil diperbarui.');
        redirect_to('index.php?m=marketplace');
    }
    if ($_POST['aksi'] === 'hapus') {
        mysqli_query($koneksi, "DELETE FROM tb_marketplace WHERE id_marketplace = " . (int) $_POST['id']);
        flash_set('success', 'Marketplace berhasil dihapus.');
        redirect_to('index.php?m=marketplace');
    }
}

$editData = $edit_id ? fetch_one("SELECT * FROM tb_marketplace WHERE id_marketplace = $edit_id") : null;
$where = '';
if ($q !== '') {
    $safeQ = mysqli_real_escape_string($koneksi, $q);
    $where = "WHERE nama_marketplace LIKE '%$safeQ%' OR nama_toko LIKE '%$safeQ%' OR status LIKE '%$safeQ%'";
}
$rows = fetch_all("SELECT * FROM tb_marketplace $where ORDER BY id_marketplace DESC");
include __DIR__ . '/../layout_top.php'; ?>
<div class="content-card">
    <div class="row">
        <div class="col-md-6">
            <h4>Data Marketplace</h4>
            <p class="text-muted">Atur marketplace dan nama toko.</p>
        </div>
        <div class="col-md-6 text-right">
            <button class="btn btn-primary" data-toggle="collapse" data-target="#formMarket">Tambah Marketplace</button>
        </div>
    </div>

    <form method="get" class="row" style="margin:14px 0 6px">
        <input type="hidden" name="m" value="marketplace">
        <div class="col-md-9 form-group">
            <label>Cari Marketplace</label>
            <input class="form-control" name="q" value="<?php echo esc($q); ?>" placeholder="Cari marketplace, nama toko, atau status...">
        </div>
        <div class="col-md-3 form-group">
            <label>&nbsp;</label>
            <div class="btn-group btn-block">
                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Cari</button>
                <?php if ($q !== ''): ?><a class="btn btn-default" href="index.php?m=marketplace">Reset</a><?php endif; ?>
            </div>
        </div>
    </form>
    <?php if ($q !== ''): ?><p class="text-muted">Hasil pencarian untuk "<?php echo esc($q); ?>": <?php echo count($rows); ?> data.</p><?php endif; ?>

    <div id="formMarket" class="collapse <?php echo $editData ? 'in' : ''; ?>" style="margin-top:18px">
        <form method="post" class="row">
            <input type="hidden" name="aksi" value="<?php echo $editData ? 'update' : 'tambah'; ?>">
            <?php if ($editData): ?><input type="hidden" name="id" value="<?php echo (int) $editData['id_marketplace']; ?>"><?php endif; ?>
            <div class="col-md-4 form-group"><label>Nama Marketplace</label><input class="form-control" name="nama_marketplace" value="<?php echo esc($editData['nama_marketplace'] ?? ''); ?>"></div>
            <div class="col-md-4 form-group"><label>Nama Toko</label><input class="form-control" name="nama_toko" value="<?php echo esc($editData['nama_toko'] ?? ''); ?>"></div>
            <div class="col-md-2 form-group"><label>Status</label><select class="form-control" name="status"><option value="aktif" <?php echo selected_attr($editData['status'] ?? 'aktif', 'aktif'); ?>>Aktif</option><option value="nonaktif" <?php echo selected_attr($editData['status'] ?? '', 'nonaktif'); ?>>Nonaktif</option></select></div>
            <div class="col-md-2 form-group"><label>&nbsp;</label><button class="btn btn-success btn-block">Simpan</button></div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead><tr><th>ID</th><th>Marketplace</th><th>Nama Toko</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="5" class="text-center text-muted">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?php echo (int)$row['id_marketplace']; ?></td>
                        <td><?php echo esc($row['nama_marketplace']); ?></td>
                        <td><?php echo esc($row['nama_toko']); ?></td>
                        <td><?php echo badge_status($row['status']); ?></td>
                        <td><a class="btn btn-xs btn-info" href="index.php?m=marketplace&edit=<?php echo (int)$row['id_marketplace']; ?><?php echo $q !== '' ? '&q=' . urlencode($q) : ''; ?>">Edit</a> <form method="post" style="display:inline"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?php echo (int)$row['id_marketplace']; ?>"><button class="btn btn-xs btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</button></form></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>
