<?php
$active = 'petugas';
$page_title = 'Petugas';
$edit_id = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah' && require_post_fields(['nama', 'username', 'password'])) {
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
        $username = mysqli_real_escape_string($koneksi, $_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $foto = mysqli_real_escape_string($koneksi, handle_photo_upload('foto', 'petugas'));
        mysqli_query($koneksi, "INSERT INTO tb_petugas(nama,foto,username,password,status,created_at) VALUES('$nama','$foto','$username','$password','aktif',NOW())");
        log_activity('admin', $_SESSION['id_admin'], $_SESSION['nama_admin'], 'Menambah data petugas');
        flash_set('success', 'Data petugas berhasil ditambahkan.');
        redirect_to('index.php?m=petugas');
    }

    if ($_POST['aksi'] === 'update' && require_post_fields(['id', 'nama', 'username'])) {
        $id = (int) $_POST['id'];
        $old = fetch_one("SELECT * FROM tb_petugas WHERE id_petugas = $id");
        if ($old) {
            $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
            $username = mysqli_real_escape_string($koneksi, $_POST['username']);
            $status = mysqli_real_escape_string($koneksi, $_POST['status'] ?: 'aktif');
            $foto = mysqli_real_escape_string($koneksi, handle_photo_upload('foto', 'petugas', $old['foto'] ?? ''));
            $sqlPassword = '';
            if (!empty($_POST['password'])) {
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $sqlPassword = ", password='" . mysqli_real_escape_string($koneksi, $password) . "'";
            }
            mysqli_query($koneksi, "UPDATE tb_petugas SET nama='$nama', foto='$foto', username='$username', status='$status' $sqlPassword WHERE id_petugas = $id");
            log_activity('admin', $_SESSION['id_admin'], $_SESSION['nama_admin'], 'Memperbarui data petugas');
            flash_set('success', 'Data petugas berhasil diperbarui.');
        }
        redirect_to('index.php?m=petugas');
    }

    if ($_POST['aksi'] === 'hapus') {
        $id = (int) $_POST['id'];
        $old = fetch_one("SELECT foto FROM tb_petugas WHERE id_petugas = $id");
        if ($old) {
            delete_uploaded_file($old['foto']);
        }
        mysqli_query($koneksi, "DELETE FROM tb_petugas WHERE id_petugas = $id");
        flash_set('success', 'Data petugas berhasil dihapus.');
        redirect_to('index.php?m=petugas');
    }
}

$editData = $edit_id ? fetch_one("SELECT * FROM tb_petugas WHERE id_petugas = $edit_id") : null;
$rows = fetch_all("SELECT * FROM tb_petugas ORDER BY id_petugas DESC");
include __DIR__ . '/../layout_top.php';
?>
<div class="content-card">
    <div class="row"><div class="col-md-6"><h4>Petugas</h4><p class="text-muted">Atur akun petugas dan statusnya.</p></div><div class="col-md-6 text-right"><button class="btn btn-primary" data-toggle="collapse" data-target="#formPetugas">Tambah Petugas</button></div></div>
    <div id="formPetugas" class="collapse <?php echo $editData ? 'in' : ''; ?>" style="margin-top:18px">
        <form method="post" enctype="multipart/form-data" class="row">
            <input type="hidden" name="aksi" value="<?php echo $editData ? 'update' : 'tambah'; ?>">
            <?php if ($editData): ?><input type="hidden" name="id" value="<?php echo (int) $editData['id_petugas']; ?>"><?php endif; ?>
            <div class="col-md-4 form-group"><label>Nama</label><input class="form-control" name="nama" value="<?php echo esc($editData['nama'] ?? ''); ?>"></div>
            <div class="col-md-3 form-group"><label>Username</label><input class="form-control" name="username" value="<?php echo esc($editData['username'] ?? ''); ?>"></div>
            <div class="col-md-3 form-group"><label><?php echo $editData ? 'Password baru' : 'Password'; ?></label><input type="password" class="form-control" name="password"></div>
            <div class="col-md-2 form-group"><label>Status</label><select class="form-control" name="status"><option value="aktif" <?php echo selected_attr($editData['status'] ?? 'aktif', 'aktif'); ?>>Aktif</option><option value="nonaktif" <?php echo selected_attr($editData['status'] ?? '', 'nonaktif'); ?>>Nonaktif</option></select></div>
            <div class="col-md-4 form-group"><label>Foto</label><input type="file" class="form-control" name="foto" accept="image/*"></div>
            <div class="col-md-4 form-group"><?php if ($editData): ?><label>Foto saat ini</label><div><?php echo photo_tag($editData['foto'] ?? '', $editData['nama'], 'avatar-thumb large'); ?></div><?php endif; ?></div>
            <div class="col-md-4 form-group"><label>&nbsp;</label><button class="btn btn-success btn-block">Simpan</button></div>
        </form>
    </div>
    <div class="table-responsive"><table class="table table-striped"><thead><tr><th>Foto</th><th>ID</th><th>Nama</th><th>Username</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
    <?php foreach ($rows as $row): ?>
        <tr>
            <td><?php echo photo_tag($row['foto'] ?? '', $row['nama']); ?></td>
            <td><?php echo (int)$row['id_petugas']; ?></td>
            <td><?php echo esc($row['nama']); ?></td>
            <td><?php echo esc($row['username']); ?></td>
            <td><?php echo badge_status($row['status']); ?></td>
            <td><a class="btn btn-xs btn-info" href="index.php?m=petugas&edit=<?php echo (int)$row['id_petugas']; ?>">Edit</a> <form method="post" style="display:inline"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?php echo (int)$row['id_petugas']; ?>"><button class="btn btn-xs btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</button></form></td>
        </tr>
    <?php endforeach; ?>
    </tbody></table></div>
</div>
<?php include __DIR__ . '/../layout_bottom.php'; ?>