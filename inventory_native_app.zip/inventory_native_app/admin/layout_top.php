<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$active = isset($active) ? $active : 'dashboard';
$namaAdmin = isset($_SESSION['nama_admin']) ? $_SESSION['nama_admin'] : 'Admin';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc($page_title ?? 'Admin'); ?></title>
    <link rel="stylesheet" href="../vendor/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/modern.css">
    
</head>
<body class="admin-shell">
<nav class="navbar admin-navbar">
    <div class="container-fluid">
        <div class="navbar-header"><a class="navbar-brand" href="index.php">Admin KSI</a></div>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="../index.php" target="_blank"><i class="fa fa-globe"></i> Beranda</a></li>
            <li><a href="#"><i class="fa fa-user-circle"></i> <?php echo esc($namaAdmin); ?></a></li>
            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
    </div>
</nav>
<div class="container-fluid">
<div class="row">
<aside class="col-sm-3 col-md-2 admin-sidebar">
    <div class="brand-mini">Menu Admin</div>
    <a href="index.php?m=dashboard" class="<?php echo $active === 'dashboard' ? 'active' : ''; ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
    <a href="index.php?m=admin" class="<?php echo $active === 'admin' ? 'active' : ''; ?>"><i class="fa fa-user-secret"></i> Admin</a>
    <a href="index.php?m=petugas" class="<?php echo $active === 'petugas' ? 'active' : ''; ?>"><i class="fa fa-users"></i> Petugas</a>
    <a href="index.php?m=marketplace" class="<?php echo $active === 'marketplace' ? 'active' : ''; ?>"><i class="fa fa-shopping-bag"></i> Marketplace</a>
    <a href="index.php?m=rak" class="<?php echo $active === 'rak' ? 'active' : ''; ?>"><i class="fa fa-cubes"></i> Rak</a>
    <a href="index.php?m=item" class="<?php echo $active === 'item' ? 'active' : ''; ?>"><i class="fa fa-archive"></i> Item</a>
    <a href="index.php?m=itemMasuk" class="<?php echo $active === 'itemMasuk' ? 'active' : ''; ?>"><i class="fa fa-arrow-circle-down"></i> Item Masuk</a>
    <a href="index.php?m=itemKeluar" class="<?php echo $active === 'itemKeluar' ? 'active' : ''; ?>"><i class="fa fa-arrow-circle-up"></i> Item Keluar</a>
    <a href="index.php?m=ajuan" class="<?php echo $active === 'ajuan' ? 'active' : ''; ?>"><i class="fa fa-file-text"></i> Ajuan</a>
    <a href="index.php?m=laporan" class="<?php echo $active === 'laporan' ? 'active' : ''; ?>"><i class="fa fa-bar-chart"></i> Laporan</a>
</aside>
<main class="col-sm-9 col-md-10 admin-content">
    <?php flash_show(); ?>
