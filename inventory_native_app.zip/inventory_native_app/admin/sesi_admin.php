<?php
require_once __DIR__ . '/../helpers.php';
session_timeout_check();
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (empty($_SESSION['admin_login'])) {
    redirect_to('login.php');
}
