<?php
$site_title = 'Sistem Inventory Marketplace PT. KSI';
$base_url = '';
$session_timeout = 1800;

date_default_timezone_set('Asia/Jakarta');

function esc($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect_to($path)
{
    header('Location: ' . $path);
    exit;
}

function format_tanggal($tanggal)
{
    if (!$tanggal) {
        return '-';
    }
    return date('d-m-Y', strtotime($tanggal));
}

function flash_set($type, $message)
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function flash_show()
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        $class = $flash['type'] === 'success' ? 'alert-success' : ($flash['type'] === 'warning' ? 'alert-warning' : 'alert-danger');
        echo '<div class="alert ' . $class . '">' . esc($flash['message']) . '</div>';
    }
}
